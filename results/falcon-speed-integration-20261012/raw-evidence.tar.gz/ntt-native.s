	.file	"ntt_assembly.8398a3417b8ad2a5-cgu.0"
	.section	.text.unlikely._RINvMNtNtCs9k3SxhrAWiO_3std4sync9once_lockINtB3_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB2_11get_or_initNCNvMBV_NtBV_19PolynomialWorkspace3new0E0zEBV_,"ax",@progbits
	.type	_RINvMNtNtCs9k3SxhrAWiO_3std4sync9once_lockINtB3_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB2_11get_or_initNCNvMBV_NtBV_19PolynomialWorkspace3new0E0zEBV_,@function
_RINvMNtNtCs9k3SxhrAWiO_3std4sync9once_lockINtB3_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB2_11get_or_initNCNvMBV_NtBV_19PolynomialWorkspace3new0E0zEBV_:
	.cfi_startproc
	movl	56(%rdi), %eax
	testl	%eax, %eax
	jne	.LBB0_1
	retq
.LBB0_1:
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	leaq	16(%rsp), %rax
	leaq	8(%rsp), %rdx
	leaq	7(%rsp), %rcx
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.2(%rip), %r8
	movq	%rsi, (%rax)
	movq	%rdi, 8(%rax)
	movq	%rcx, 16(%rax)
	addq	$56, %rdi
	movq	%rax, (%rdx)
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.0(%rip), %rcx
	pushq	$1
	.cfi_adjust_cfa_offset 8
	popq	%rsi
	.cfi_adjust_cfa_offset -8
	callq	*_RNvMs0_NtNtNtNtCs9k3SxhrAWiO_3std3sys4sync4once5futexNtB5_4Once4call@GOTPCREL(%rip)
	addq	$40, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RINvMNtNtCs9k3SxhrAWiO_3std4sync9once_lockINtB3_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB2_11get_or_initNCNvMBV_NtBV_19PolynomialWorkspace3new0E0zEBV_, .Lfunc_end0-_RINvMNtNtCs9k3SxhrAWiO_3std4sync9once_lockINtB3_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB2_11get_or_initNCNvMBV_NtBV_19PolynomialWorkspace3new0E0zEBV_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtCsbitZm3QGn75_12ntt_assembly19PolynomialWorkspaceEBD_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtCsbitZm3QGn75_12ntt_assembly19PolynomialWorkspaceEBD_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtCsbitZm3QGn75_12ntt_assembly19PolynomialWorkspaceEBD_:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	(%rdi), %rsi
	movq	%rdi, %rbx
	testq	%rsi, %rsi
	je	.LBB1_2
	movq	8(%rbx), %rdi
	shlq	$3, %rsi
	movl	$8, %edx
	callq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB1_2:
	movq	24(%rbx), %rsi
	testq	%rsi, %rsi
	je	.LBB1_4
	movq	32(%rbx), %rdi
	shlq	$2, %rsi
	movl	$4, %edx
	callq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB1_4:
	movq	48(%rbx), %rsi
	testq	%rsi, %rsi
	je	.LBB1_5
	movq	56(%rbx), %rdi
	shlq	$2, %rsi
	movl	$4, %edx
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmpq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB1_5:
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtCsbitZm3QGn75_12ntt_assembly19PolynomialWorkspaceEBD_, .Lfunc_end1-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtCsbitZm3QGn75_12ntt_assembly19PolynomialWorkspaceEBD_
	.cfi_endproc

	.section	.text._RNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtB8_4Once15call_once_forceNCINvMNtBa_9once_lockINtB1b_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1a_11get_or_initNCNvMB1I_NtB1I_19PolynomialWorkspace3new0E0zE0E0B1I_,"ax",@progbits
	.p2align	4
	.type	_RNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtB8_4Once15call_once_forceNCINvMNtBa_9once_lockINtB1b_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1a_11get_or_initNCNvMB1I_NtB1I_19PolynomialWorkspace3new0E0zE0E0B1I_,@function
_RNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtB8_4Once15call_once_forceNCINvMNtBa_9once_lockINtB1b_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1a_11get_or_initNCNvMB1I_NtB1I_19PolynomialWorkspace3new0E0zE0E0B1I_:
.Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception0
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$184, %rsp
	.cfi_def_cfa_offset 240
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	(%rdi), %rcx
	movq	(%rcx), %rax
	movq	8(%rcx), %r9
	movq	$0, (%rcx)
	testq	%rax, %rax
	je	.LBB2_83
	movq	(%rax), %r10
	addq	%r10, %r10
	testl	%r10d, %r10d
	je	.LBB2_84
	movl	$1, %edi
	cmpl	$12288, %r10d
	jbe	.LBB2_3
.LBB2_7:
	movl	$2863078533, %r13d
	movq	$0, 48(%rsp)
	movq	$8, 56(%rsp)
	movq	$0, 24(%rsp)
	movq	$8, 32(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 40(%rsp)
	testq	%r10, %r10
	je	.LBB2_19
	movl	%edi, %eax
	imulq	%r13, %rax
	movl	%edi, %ebx
	imull	%ebx, %ebx
	movabsq	$9223372036854775804, %r11
	movq	%r9, 88(%rsp)
	xorl	%r8d, %r8d
	movq	%r10, %rsi
	shrq	$45, %rax
	imull	$12289, %eax, %ecx
	movl	%edi, %eax
	subl	%ecx, %eax
	imulq	$1431539267, %rbx, %rcx
	shrq	$44, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %eax
	imull	%ebx, %ebx
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%ebx, %ebx
	imulq	$357884817, %rbx, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebx
	imull	%eax, %ebx
	movl	$8, %eax
	movq	%rax, 104(%rsp)
.LBB2_9:
	movq	%r10, %rax
	orq	%rsi, %rax
	shrq	$32, %rax
	je	.LBB2_10
	movq	%r10, %rax
	xorl	%edx, %edx
	divq	%rsi
	movq	%rax, %r12
	movl	$1, %r14d
	movq	%r8, 72(%rsp)
	testl	%r12d, %r12d
	jne	.LBB2_44
	jmp	.LBB2_22
	.p2align	4
.LBB2_10:
	movl	%r10d, %eax
	xorl	%edx, %edx
	divl	%esi
	movl	%eax, %r12d
	movl	$1, %r14d
	movq	%r8, 72(%rsp)
	testl	%r12d, %r12d
	je	.LBB2_22
.LBB2_44:
	movl	%edi, %eax
	movl	%r12d, %ecx
	jmp	.LBB2_45
	.p2align	4
.LBB2_47:
	imull	%eax, %eax
	imulq	$1431539267, %rax, %rdx
	shrq	$44, %rdx
	imull	$12289, %edx, %edx
	subl	%edx, %eax
	shrl	%ecx
	je	.LBB2_22
.LBB2_45:
	testb	$1, %cl
	je	.LBB2_47
	imull	%eax, %r14d
	movq	%r14, %rdx
	imulq	%r13, %rdx
	shrq	$45, %rdx
	imull	$12289, %edx, %edx
	subl	%edx, %r14d
	jmp	.LBB2_47
	.p2align	4
.LBB2_22:
	movq	%rsi, %rdx
	shrq	%rdx
	testq	%rsi, %rsi
	leaq	(,%rdx,4), %rbp
	sets	%al
	cmpq	%r11, %rbp
	movq	%rbp, 112(%rsp)
	seta	%cl
	orb	%al, %cl
	jne	.LBB2_23
	movq	%rdx, 8(%rsp)
	movq	%rsi, 80(%rsp)
	movq	%rdi, 120(%rsp)
	movq	%r10, 96(%rsp)
	testq	%rbp, %rbp
	je	.LBB2_25
	callq	*_RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$4, %esi
	movq	%rbp, %rdi
	movl	$4, %r15d
	callq	*_RNvCs1njKG4L9aB3_7___rustc12___rust_alloc@GOTPCREL(%rip)
	movq	%rax, %rbp
	movq	8(%rsp), %rax
	movq	%rax, 16(%rsp)
	testq	%rbp, %rbp
	je	.LBB2_67
	movq	%rax, %r15
	testq	%rax, %rax
	jne	.LBB2_28
	jmp	.LBB2_35
.LBB2_25:
	movq	8(%rsp), %rax
	movl	$4, %ebp
	movq	$0, 16(%rsp)
	movq	%rax, %r15
	testq	%rax, %rax
	je	.LBB2_35
.LBB2_28:
	movl	%r15d, %eax
	andl	$7, %eax
	cmpq	$16, 80(%rsp)
	jae	.LBB2_30
	movl	$1, %esi
	xorl	%ecx, %ecx
	jmp	.LBB2_33
.LBB2_30:
	movabsq	$4611686018427387896, %rcx
	movq	%r15, %rdx
	movl	$1, %esi
	andq	%rcx, %rdx
	xorl	%ecx, %ecx
	.p2align	4
.LBB2_31:
	movl	%esi, (%rbp,%rcx,4)
	imull	%r14d, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 4(%rbp,%rcx,4)
	imull	%r14d, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 8(%rbp,%rcx,4)
	imull	%r14d, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 12(%rbp,%rcx,4)
	imull	%r14d, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 16(%rbp,%rcx,4)
	imull	%r14d, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 20(%rbp,%rcx,4)
	imull	%r14d, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 24(%rbp,%rcx,4)
	imull	%r14d, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 28(%rbp,%rcx,4)
	imull	%r14d, %esi
	addq	$8, %rcx
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	cmpq	%rcx, %rdx
	jne	.LBB2_31
	testq	%rax, %rax
	je	.LBB2_35
.LBB2_33:
	leaq	(%rbp,%rcx,4), %rcx
	xorl	%edx, %edx
	.p2align	4
.LBB2_34:
	movl	%esi, (%rcx,%rdx,4)
	imull	%r14d, %esi
	incq	%rdx
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	cmpq	%rdx, %rax
	jne	.LBB2_34
.LBB2_35:
	movq	72(%rsp), %r14
	cmpq	48(%rsp), %r14
	jne	.LBB2_38
.Ltmp0:
	leaq	48(%rsp), %rdi
	callq	*_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VecmEE8grow_oneCsbitZm3QGn75_12ntt_assembly@GOTPCREL(%rip)
.Ltmp1:
	movq	56(%rsp), %rax
	movq	%rax, 104(%rsp)
.LBB2_38:
	movq	104(%rsp), %rcx
	movq	16(%rsp), %rsi
	leaq	(%r14,%r14,2), %rax
	leaq	1(%r14), %rdx
	movq	%rdx, 72(%rsp)
	movq	%rsi, (%rcx,%rax,8)
	movq	%rbp, 8(%rcx,%rax,8)
	movl	$1, %ebp
	movq	%r15, 16(%rcx,%rax,8)
	movq	%rdx, 64(%rsp)
	testl	%r12d, %r12d
	je	.LBB2_39
	movl	%ebx, %eax
	jmp	.LBB2_78
	.p2align	4
.LBB2_80:
	imull	%eax, %eax
	shrl	%r12d
	je	.LBB2_39
.LBB2_78:
	movl	%eax, %ecx
	imulq	%r13, %rcx
	shrq	$45, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	testb	$1, %r12b
	je	.LBB2_80
	imull	%eax, %ebp
	movq	%rbp, %rcx
	imulq	%r13, %rcx
	shrq	$45, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %ebp
	jmp	.LBB2_80
	.p2align	4
.LBB2_39:
	movq	112(%rsp), %r14
	testq	%r14, %r14
	je	.LBB2_40
	callq	*_RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$4, %esi
	movq	%r14, %rdi
	movl	$4, %r15d
	callq	*_RNvCs1njKG4L9aB3_7___rustc12___rust_alloc@GOTPCREL(%rip)
	movq	8(%rsp), %rdx
	movq	%rax, %r14
	movq	%rdx, %r12
	testq	%rax, %rax
	je	.LBB2_67
	testq	%rdx, %rdx
	jne	.LBB2_42
	jmp	.LBB2_74
.LBB2_40:
	movq	8(%rsp), %rdx
	movl	$4, %r14d
	xorl	%r12d, %r12d
	testq	%rdx, %rdx
	je	.LBB2_74
.LBB2_42:
	movl	%edx, %eax
	andl	$7, %eax
	cmpq	$16, 80(%rsp)
	jae	.LBB2_69
	movl	$1, %esi
	xorl	%ecx, %ecx
	jmp	.LBB2_72
.LBB2_69:
	movabsq	$4611686018427387896, %rcx
	movl	$1, %esi
	andq	%rcx, %rdx
	xorl	%ecx, %ecx
	.p2align	4
.LBB2_70:
	movl	%esi, (%r14,%rcx,4)
	imull	%ebp, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 4(%r14,%rcx,4)
	imull	%ebp, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 8(%r14,%rcx,4)
	imull	%ebp, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 12(%r14,%rcx,4)
	imull	%ebp, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 16(%r14,%rcx,4)
	imull	%ebp, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 20(%r14,%rcx,4)
	imull	%ebp, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 24(%r14,%rcx,4)
	imull	%ebp, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	movl	%esi, 28(%r14,%rcx,4)
	imull	%ebp, %esi
	addq	$8, %rcx
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	cmpq	%rcx, %rdx
	jne	.LBB2_70
	testq	%rax, %rax
	je	.LBB2_74
.LBB2_72:
	leaq	(%r14,%rcx,4), %rcx
	xorl	%edx, %edx
	.p2align	4
.LBB2_73:
	movl	%esi, (%rcx,%rdx,4)
	imull	%ebp, %esi
	incq	%rdx
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$45, %rdi
	imull	$12289, %edi, %edi
	subl	%edi, %esi
	cmpq	%rdx, %rax
	jne	.LBB2_73
.LBB2_74:
	movq	40(%rsp), %r15
	cmpq	24(%rsp), %r15
	jne	.LBB2_76
.Ltmp3:
	leaq	24(%rsp), %rdi
	callq	*_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VecmEE8grow_oneCsbitZm3QGn75_12ntt_assembly@GOTPCREL(%rip)
.Ltmp4:
.LBB2_76:
	leaq	(%r15,%r15,2), %rcx
	movq	32(%rsp), %rax
	incq	%r15
	movq	8(%rsp), %rsi
	movq	72(%rsp), %r8
	cmpq	$3, 80(%rsp)
	movq	96(%rsp), %r10
	movq	120(%rsp), %rdi
	movabsq	$9223372036854775804, %r11
	movq	%r12, (%rax,%rcx,8)
	movq	%r14, 8(%rax,%rcx,8)
	movq	%rsi, 16(%rax,%rcx,8)
	movq	%r15, 40(%rsp)
	ja	.LBB2_9
	movq	88(%rsp), %r9
	movq	%r15, %rsi
	shrq	%rsi
	je	.LBB2_19
	movl	%esi, %edx
	andl	$3, %edx
	cmpq	$8, %r15
	jae	.LBB2_14
	xorl	%edi, %edi
	jmp	.LBB2_17
.LBB2_23:
	xorl	%r15d, %r15d
.LBB2_67:
.Ltmp6:
	movq	112(%rsp), %rsi
	movq	%r15, %rdi
	callq	*_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp7:
	ud2
.LBB2_3:
	movw	$12288, %ax
	xorl	%edx, %edx
	movl	$11, %ecx
	movl	$1, %edi
	divw	%r10w
	movl	$2863078533, %edx
	movzwl	%ax, %eax
	jmp	.LBB2_4
	.p2align	4
.LBB2_6:
	imull	%ecx, %ecx
	imulq	$1431539267, %rcx, %rsi
	shrq	$44, %rsi
	imull	$12289, %esi, %esi
	subl	%esi, %ecx
	shrl	%eax
	je	.LBB2_7
.LBB2_4:
	testb	$1, %al
	je	.LBB2_6
	imull	%ecx, %edi
	movq	%rdi, %rsi
	imulq	%rdx, %rsi
	shrq	$45, %rsi
	imull	$12289, %esi, %esi
	subl	%esi, %edi
	jmp	.LBB2_6
.LBB2_14:
	leaq	(%r15,%r15,2), %rdi
	leaq	16(%rax,%rcx,8), %r10
	andq	%r11, %rsi
	leaq	88(%rax), %r9
	movabsq	$2305843009213693950, %r11
	movabsq	$2305843009213693949, %rbx
	movabsq	$2305843009213693948, %r14
	leaq	(%rax,%rdi,8), %r8
	xorl	%edi, %edi
.LBB2_15:
	vmovups	-88(%r9), %xmm0
	vmovups	-16(%r10), %xmm1
	vmovups	%xmm1, -88(%r9)
	vmovups	%xmm0, -16(%r10)
	movq	-72(%r9), %r15
	movq	(%r10), %r12
	movq	%r12, -72(%r9)
	movq	%r15, (%r10)
	movq	%rdi, %r15
	xorq	%r11, %r15
	addq	$-96, %r10
	leaq	(%r15,%r15,2), %r15
	vmovups	-64(%r9), %xmm0
	vmovups	(%r8,%r15,8), %xmm1
	vmovups	%xmm1, -64(%r9)
	vmovups	%xmm0, (%r8,%r15,8)
	movq	-48(%r9), %r12
	movq	16(%r8,%r15,8), %rbp
	movq	%rbp, -48(%r9)
	movq	%r12, 16(%r8,%r15,8)
	movq	%rdi, %r15
	xorq	%rbx, %r15
	leaq	(%r15,%r15,2), %r15
	vmovups	-40(%r9), %xmm0
	vmovups	(%r8,%r15,8), %xmm1
	vmovups	%xmm1, -40(%r9)
	vmovups	%xmm0, (%r8,%r15,8)
	movq	-24(%r9), %r12
	movq	16(%r8,%r15,8), %rbp
	movq	%rbp, -24(%r9)
	movq	%r12, 16(%r8,%r15,8)
	movq	%rdi, %r15
	xorq	%r14, %r15
	addq	$4, %rdi
	leaq	(%r15,%r15,2), %r15
	vmovups	-16(%r9), %xmm0
	vmovups	(%r8,%r15,8), %xmm1
	vmovups	%xmm1, -16(%r9)
	vmovups	%xmm0, (%r8,%r15,8)
	movq	16(%r8,%r15,8), %rbp
	movq	(%r9), %r12
	movq	%rbp, (%r9)
	addq	$96, %r9
	movq	%r12, 16(%r8,%r15,8)
	cmpq	%rdi, %rsi
	jne	.LBB2_15
	movq	88(%rsp), %r9
	movq	96(%rsp), %r10
	testq	%rdx, %rdx
	je	.LBB2_19
.LBB2_17:
	shlq	$3, %rdi
	shll	$3, %edx
	leaq	(%rdi,%rdi,2), %rdi
	leaq	16(%rax,%rdi), %rsi
	subq	%rdi, %rax
	leaq	16(%rax,%rcx,8), %rax
	leaq	(%rdx,%rdx,2), %rcx
	xorl	%edx, %edx
	.p2align	4
.LBB2_18:
	vmovups	-16(%rsi,%rdx), %xmm0
	vmovups	-16(%rax), %xmm1
	vmovups	%xmm1, -16(%rsi,%rdx)
	vmovups	%xmm0, -16(%rax)
	movq	(%rsi,%rdx), %rdi
	movq	(%rax), %r8
	movq	%r8, (%rsi,%rdx)
	movq	%rdi, (%rax)
	addq	$24, %rdx
	addq	$-24, %rax
	cmpq	%rdx, %rcx
	jne	.LBB2_18
.LBB2_19:
	movq	64(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 128(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 152(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, 160(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, 168(%rsp)
	movl	%r10d, %eax
	imull	%eax, %eax
	vmovups	144(%rsp), %ymm0
	movq	%rax, %rcx
	imulq	%r13, %rcx
	shrq	$45, %rcx
	imull	$12289, %ecx, %ecx
	vmovups	%ymm0, 16(%r9)
	subl	%ecx, %eax
	movl	%r10d, %ecx
	imulq	%r13, %rcx
	vmovups	128(%rsp), %ymm0
	shrq	$45, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	vmovups	%ymm0, (%r9)
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imull	%eax, %eax
	imulq	$357884817, %rax, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %eax
	imulq	$357884817, %r10, %rcx
	shrq	$42, %rcx
	imull	$12289, %ecx, %ecx
	subl	%ecx, %r10d
	imull	%eax, %r10d
	imulq	$357884817, %r10, %rax
	shrq	$42, %rax
	imull	$12289, %eax, %eax
	subl	%eax, %r10d
	movl	%r10d, 48(%r9)
	addq	$184, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	vzeroupper
	retq
.LBB2_83:
	.cfi_def_cfa_offset 240
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.3(%rip), %rdi
	callq	*_RNvNtCsgxBkk5gSRhY_4core6option13unwrap_failed@GOTPCREL(%rip)
.LBB2_84:
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.12(%rip), %rdi
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core9panicking11panic_const23panic_const_div_by_zero@GOTPCREL(%rip)
.LBB2_81:
.Ltmp5:
	movq	%rax, %rbx
	testq	%r12, %r12
	je	.LBB2_49
	shlq	$2, %r12
	movl	$4, %edx
	movq	%r14, %rdi
	movq	%r12, %rsi
	callq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB2_49
.LBB2_64:
.Ltmp2:
	cmpq	$0, 16(%rsp)
	movq	%rax, %rbx
	je	.LBB2_49
	movq	16(%rsp), %rsi
	movl	$4, %edx
	movq	%rbp, %rdi
	shlq	$2, %rsi
	callq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB2_49
.LBB2_48:
.Ltmp8:
	movq	%rax, %rbx
.LBB2_49:
	movq	32(%rsp), %r14
	movq	40(%rsp), %r15
	testq	%r15, %r15
	jne	.LBB2_50
.LBB2_54:
	movq	24(%rsp), %rax
	testq	%rax, %rax
	je	.LBB2_56
	shlq	$3, %rax
	movl	$8, %edx
	movq	%r14, %rdi
	leaq	(%rax,%rax,2), %rsi
	callq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB2_56:
	movq	56(%rsp), %r14
	movq	64(%rsp), %r15
	testq	%r15, %r15
	jne	.LBB2_57
.LBB2_61:
	movq	48(%rsp), %rax
	testq	%rax, %rax
	je	.LBB2_63
	shlq	$3, %rax
	movl	$8, %edx
	movq	%r14, %rdi
	leaq	(%rax,%rax,2), %rsi
	callq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB2_63:
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB2_50:
	movq	_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip), %r13
	leaq	8(%r14), %r12
	jmp	.LBB2_51
	.p2align	4
.LBB2_53:
	addq	$24, %r12
	decq	%r15
	je	.LBB2_54
.LBB2_51:
	movq	-8(%r12), %rsi
	testq	%rsi, %rsi
	je	.LBB2_53
	movq	(%r12), %rdi
	shlq	$2, %rsi
	movl	$4, %edx
	callq	*%r13
	jmp	.LBB2_53
.LBB2_57:
	movq	_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip), %r13
	leaq	8(%r14), %r12
	jmp	.LBB2_58
	.p2align	4
.LBB2_60:
	addq	$24, %r12
	decq	%r15
	je	.LBB2_61
.LBB2_58:
	movq	-8(%r12), %rsi
	testq	%rsi, %rsi
	je	.LBB2_60
	movq	(%r12), %rdi
	shlq	$2, %rsi
	movl	$4, %edx
	callq	*%r13
	jmp	.LBB2_60
.Lfunc_end2:
	.size	_RNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtB8_4Once15call_once_forceNCINvMNtBa_9once_lockINtB1b_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1a_11get_or_initNCNvMB1I_NtB1I_19PolynomialWorkspace3new0E0zE0E0B1I_, .Lfunc_end2-_RNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtB8_4Once15call_once_forceNCINvMNtBa_9once_lockINtB1b_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1a_11get_or_initNCNvMB1I_NtB1I_19PolynomialWorkspace3new0E0zE0E0B1I_
	.cfi_endproc
	.section	.gcc_except_table._RNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtB8_4Once15call_once_forceNCINvMNtBa_9once_lockINtB1b_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1a_11get_or_initNCNvMB1I_NtB1I_19PolynomialWorkspace3new0E0zE0E0B1I_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table2:
.Lexception0:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end0-.Lcst_begin0
.Lcst_begin0:
	.uleb128 .Ltmp0-.Lfunc_begin0
	.uleb128 .Ltmp1-.Ltmp0
	.uleb128 .Ltmp2-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp3-.Lfunc_begin0
	.uleb128 .Ltmp4-.Ltmp3
	.uleb128 .Ltmp5-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp6-.Lfunc_begin0
	.uleb128 .Ltmp7-.Ltmp6
	.uleb128 .Ltmp8-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp7-.Lfunc_begin0
	.uleb128 .Lfunc_end2-.Ltmp7
	.byte	0
	.byte	0
.Lcst_end0:
	.p2align	2, 0x0

	.section	.text._RNSNvYNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtBd_4Once15call_once_forceNCINvMNtBf_9once_lockINtB1g_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1f_11get_or_initNCNvMB1N_NtB1N_19PolynomialWorkspace3new0E0zE0E0INtNtNtCsgxBkk5gSRhY_4core3ops8function6FnOnceTRNtBd_9OnceStateEE9call_once6vtableB1N_,"ax",@progbits
	.p2align	4
	.type	_RNSNvYNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtBd_4Once15call_once_forceNCINvMNtBf_9once_lockINtB1g_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1f_11get_or_initNCNvMB1N_NtB1N_19PolynomialWorkspace3new0E0zE0E0INtNtNtCsgxBkk5gSRhY_4core3ops8function6FnOnceTRNtBd_9OnceStateEE9call_once6vtableB1N_,@function
_RNSNvYNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtBd_4Once15call_once_forceNCINvMNtBf_9once_lockINtB1g_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1f_11get_or_initNCNvMB1N_NtB1N_19PolynomialWorkspace3new0E0zE0E0INtNtNtCsgxBkk5gSRhY_4core3ops8function6FnOnceTRNtBd_9OnceStateEE9call_once6vtableB1N_:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rax
	movq	%rsp, %rdi
	movq	%rax, (%rsp)
	callq	_RNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtB8_4Once15call_once_forceNCINvMNtBa_9once_lockINtB1b_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1a_11get_or_initNCNvMB1I_NtB1I_19PolynomialWorkspace3new0E0zE0E0B1I_
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RNSNvYNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtBd_4Once15call_once_forceNCINvMNtBf_9once_lockINtB1g_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1f_11get_or_initNCNvMB1N_NtB1N_19PolynomialWorkspace3new0E0zE0E0INtNtNtCsgxBkk5gSRhY_4core3ops8function6FnOnceTRNtBd_9OnceStateEE9call_once6vtableB1N_, .Lfunc_end3-_RNSNvYNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtBd_4Once15call_once_forceNCINvMNtBf_9once_lockINtB1g_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1f_11get_or_initNCNvMB1N_NtB1N_19PolynomialWorkspace3new0E0zE0E0INtNtNtCsgxBkk5gSRhY_4core3ops8function6FnOnceTRNtBd_9OnceStateEE9call_once6vtableB1N_
	.cfi_endproc

	.section	.text.unlikely._RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VecmEE8grow_oneCsbitZm3QGn75_12ntt_assembly,"ax",@progbits
	.globl	_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VecmEE8grow_oneCsbitZm3QGn75_12ntt_assembly
	.p2align	4
	.type	_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VecmEE8grow_oneCsbitZm3QGn75_12ntt_assembly,@function
_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VecmEE8grow_oneCsbitZm3QGn75_12ntt_assembly:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$24, %rsp
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	(%rdi), %rsi
	movq	8(%rdi), %rdx
	movl	$4, %r14d
	movl	$8, %r8d
	movl	$24, %r9d
	movq	%rdi, %rbx
	movq	%rsp, %rdi
	leaq	(%rsi,%rsi), %rax
	cmpq	$5, %rax
	cmovaeq	%rax, %r14
	movq	%r14, %rcx
	callq	_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsbitZm3QGn75_12ntt_assembly
	cmpl	$1, (%rsp)
	je	.LBB4_2
	movq	8(%rsp), %rax
	movq	%rax, 8(%rbx)
	movq	%r14, (%rbx)
	addq	$24, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB4_2:
	.cfi_def_cfa_offset 48
	movq	8(%rsp), %rdi
	movq	16(%rsp), %rsi
	callq	*_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Lfunc_end4:
	.size	_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VecmEE8grow_oneCsbitZm3QGn75_12ntt_assembly, .Lfunc_end4-_RNvMs4_NtCs6i54tJFfzR_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VecmEE8grow_oneCsbitZm3QGn75_12ntt_assembly
	.cfi_endproc

	.section	.text.unlikely._RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsbitZm3QGn75_12ntt_assembly,"ax",@progbits
	.p2align	4
	.type	_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsbitZm3QGn75_12ntt_assembly,@function
_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsbitZm3QGn75_12ntt_assembly:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%r8, %r15
	movq	%rdx, %r8
	movq	%r9, %rax
	mulq	%rcx
	movabsq	$-9223372036854775808, %rcx
	movl	$1, %r12d
	movq	%rdi, %rbx
	seto	%dl
	subq	%r15, %rcx
	movq	%rax, %r14
	cmpq	%rcx, %r14
	seta	%cl
	orb	%dl, %cl
	je	.LBB5_2
	movl	$8, %eax
	xorl	%r14d, %r14d
	jmp	.LBB5_10
.LBB5_2:
	testq	%rsi, %rsi
	je	.LBB5_4
	imulq	%rsi, %r9
	movq	%r8, %rdi
	movq	%r15, %rdx
	movq	%r14, %rcx
	movq	%r9, %rsi
	callq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_realloc@GOTPCREL(%rip)
	testq	%rax, %rax
	jne	.LBB5_6
	jmp	.LBB5_9
.LBB5_4:
	testq	%r14, %r14
	je	.LBB5_5
	callq	*_RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movq	%r14, %rdi
	movq	%r15, %rsi
	callq	*_RNvCs1njKG4L9aB3_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	jne	.LBB5_6
.LBB5_9:
	movl	$16, %eax
	movq	%r15, 8(%rbx)
	jmp	.LBB5_10
.LBB5_5:
	movq	%r15, %rax
.LBB5_6:
	movq	%rax, 8(%rbx)
	movl	$16, %eax
	xorl	%r12d, %r12d
.LBB5_10:
	movq	%r14, (%rbx,%rax)
	movq	%r12, (%rbx)
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end5:
	.size	_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsbitZm3QGn75_12ntt_assembly, .Lfunc_end5-_RNvMs5_NtCs6i54tJFfzR_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsbitZm3QGn75_12ntt_assembly
	.cfi_endproc

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI6_0:
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
.LCPI6_1:
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
.LCPI6_8:
	.long	1
	.long	9
	.long	3
	.long	11
	.long	5
	.long	13
	.long	7
	.long	15
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.LCPI6_2:
	.long	36867
.LCPI6_3:
	.long	2863078533
.LCPI6_5:
	.long	12289
.LCPI6_6:
	.long	4294955007
.LCPI6_11:
	.byte	1
	.byte	5
	.byte	3
	.byte	7
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
.LCPI6_4:
	.long	1
	.long	17
	.long	3
	.long	19
	.long	5
	.long	21
	.long	7
	.long	23
	.long	9
	.long	25
	.long	11
	.long	27
	.long	13
	.long	29
	.long	15
	.long	31
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI6_7:
	.long	1
	.long	5
	.long	3
	.long	7
.LCPI6_9:
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
	.short	21839
.LCPI6_10:
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.short	12289
	.section	.text.review_ntt_product,"ax",@progbits
	.globl	review_ntt_product
	.p2align	4
	.type	review_ntt_product,@function
review_ntt_product:
.Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception1
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$216, %rsp
	.cfi_def_cfa_offset 272
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %r15
	movq	%rcx, %rbp
	movq	%rsi, %r12
	movq	%rdx, 104(%rsp)
	movq	%rdx, 48(%rsp)
	movq	%rdi, 120(%rsp)
	cmpq	$512, %rdx
	je	.LBB6_3
	cmpq	$1024, %rdx
	jne	.LBB6_2
	leaq	_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new11TABLES_1024(%rip), %rax
	movq	%rax, (%rsp)
	movl	_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new11TABLES_1024+56(%rip), %eax
	jmp	.LBB6_5
.LBB6_3:
	leaq	_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new10TABLES_512(%rip), %rax
	movq	%rax, (%rsp)
	movl	_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new10TABLES_512+56(%rip), %eax
.LBB6_5:
	testl	%eax, %eax
	jne	.LBB6_6
.LBB6_7:
	movq	%rdx, %rbx
	shlq	$4, %rbx
	movq	%rdx, %r14
	callq	*_RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$8, %esi
	movq	%rbx, %rdi
	movq	%rbx, 40(%rsp)
	callq	*_RNvCs1njKG4L9aB3_7___rustc19___rust_alloc_zeroed@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB6_136
	movq	%rax, %rbx
	leaq	(,%r14,8), %r14
	callq	*_RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$4, %esi
	movq	%r14, %rdi
	callq	*_RNvCs1njKG4L9aB3_7___rustc19___rust_alloc_zeroed@GOTPCREL(%rip)
	movq	%rbx, 80(%rsp)
	testq	%rax, %rax
	je	.LBB6_9
	movq	%r15, 8(%rsp)
	movq	%rax, 32(%rsp)
	movq	%rax, %r15
	callq	*_RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$4, %esi
	movq	%r14, %rdi
	movq	%r14, 88(%rsp)
	callq	*_RNvCs1njKG4L9aB3_7___rustc19___rust_alloc_zeroed@GOTPCREL(%rip)
	movq	%r15, 24(%rsp)
	testq	%rax, %rax
	je	.LBB6_13
	movq	48(%rsp), %rdi
	movq	8(%rsp), %rdx
	movq	(%rsp), %rcx
	leaq	(%rdi,%rdi), %r13
	movq	%rdi, 128(%rsp)
	movq	%rdx, 104(%rsp)
	movq	%r13, 136(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%r13, 152(%rsp)
	movq	%r13, 160(%rsp)
	movq	%r15, 168(%rsp)
	movq	%r13, 176(%rsp)
	movq	%r13, 184(%rsp)
	movq	%rax, 192(%rsp)
	movq	%r13, 200(%rsp)
	movq	%rcx, 208(%rsp)
	cmpq	%rdi, %rdx
	jne	.LBB6_24
	leaq	-1(%rdi), %r10
	cmpq	%r10, %r13
	cmovbq	%r13, %r10
	cmpq	$15, %r10
	ja	.LBB6_22
	movq	32(%rsp), %r8
	xorl	%r10d, %r10d
	jmp	.LBB6_19
.LBB6_22:
	vbroadcasti128	.LCPI6_9(%rip), %ymm0
	vbroadcasti128	.LCPI6_10(%rip), %ymm1
	vpbroadcastd	.LCPI6_2(%rip), %zmm2
	vpbroadcastd	.LCPI6_3(%rip), %zmm3
	vmovdqa64	.LCPI6_4(%rip), %zmm4
	vpbroadcastd	.LCPI6_5(%rip), %zmm5
	movq	32(%rsp), %r8
	incq	%r10
	movl	$16, %edx
	movq	%r15, %rsi
	movl	%r10d, %ecx
	andl	$15, %ecx
	cmovneq	%rcx, %rdx
	xorl	%ecx, %ecx
	subq	%rdx, %r10
	.p2align	4
.LBB6_23:
	vmovdqu	(%r12,%rcx,2), %ymm6
	vpmulhuw	%ymm0, %ymm6, %ymm7
	vpsubw	%ymm7, %ymm6, %ymm8
	vpsrlw	$1, %ymm8, %ymm8
	vpaddw	%ymm7, %ymm8, %ymm7
	vpsrlw	$13, %ymm7, %ymm7
	vpmullw	%ymm1, %ymm7, %ymm7
	vpsubw	%ymm7, %ymm6, %ymm6
	vpmovsxwd	(%rbp,%rcx,2), %zmm7
	vpmovzxwd	%ymm6, %zmm6
	vmovdqu64	%zmm6, (%rsi,%rcx,4)
	vpaddd	%zmm2, %zmm7, %zmm6
	vpshufd	$245, %zmm6, %zmm8
	vpmuludq	%zmm3, %zmm6, %zmm7
	vpmuludq	%zmm3, %zmm8, %zmm8
	vpermt2d	%zmm8, %zmm4, %zmm7
	vpsrld	$13, %zmm7, %zmm7
	vpmulld	%zmm5, %zmm7, %zmm7
	vpsubd	%zmm7, %zmm6, %zmm6
	vmovdqu64	%zmm6, (%rax,%rcx,4)
	addq	$16, %rcx
	cmpq	%rcx, %r10
	jne	.LBB6_23
.LBB6_19:
	movq	%rdi, %rcx
	leaq	(%r8,%r10,4), %rsi
	leaq	(%r12,%r10,2), %rdx
	leaq	(%rbp,%r10,2), %rdi
	leaq	(%rax,%r10,4), %r8
	movq	%r13, %r9
	subq	%r10, %rcx
	subq	%r10, %r9
	movl	$2863078533, %r10d
	movq	%rax, 56(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB6_20:
	cmpq	%rax, %r9
	je	.LBB6_21
	movzwl	(%rdx,%rax,2), %r11d
	imull	$21839, %r11d, %ebx
	movl	%r11d, %ebp
	shrl	$16, %ebx
	subl	%ebx, %ebp
	movzwl	%bp, %ebp
	shrl	%ebp
	addl	%ebx, %ebp
	shrl	$13, %ebp
	imull	$12289, %ebp, %ebx
	subl	%ebx, %r11d
	movzwl	%r11w, %r11d
	movl	%r11d, (%rsi,%rax,4)
	movswl	(%rdi,%rax,2), %r11d
	movl	%r11d, %ebx
	addl	$36867, %r11d
	imulq	%r10, %r11
	shrq	$45, %r11
	imull	$12289, %r11d, %r11d
	negl	%r11d
	leal	36867(%rbx,%r11), %r11d
	movl	%r11d, (%r8,%rax,4)
	incq	%rax
	cmpq	%rax, %rcx
	jne	.LBB6_20
	movq	48(%rsp), %rbx
	movq	32(%rsp), %rax
	movq	memset@GOTPCREL(%rip), %r14
	xorl	%esi, %esi
	leaq	(,%rbx,4), %r12
	leaq	(%rax,%rbx,4), %rdi
	movq	%r12, %rdx
	vzeroupper
	callq	*%r14
	movq	56(%rsp), %rax
	xorl	%esi, %esi
	movq	%r12, %rdx
	leaq	(%rax,%rbx,4), %rdi
	callq	*%r14
	movq	(%rsp), %rax
	movq	%r13, 96(%rsp)
	movq	16(%rax), %rax
	testq	%rax, %rax
	je	.LBB6_68
	movq	(%rsp), %rcx
	vpbroadcastd	.LCPI6_6(%rip), %xmm0
	vpbroadcastd	.LCPI6_5(%rip), %xmm1
	vpbroadcastd	.LCPI6_3(%rip), %xmm2
	vpmovsxbd	.LCPI6_11(%rip), %xmm3
	vpbroadcastd	.LCPI6_6(%rip), %zmm4
	vpbroadcastd	.LCPI6_5(%rip), %zmm5
	vpbroadcastd	.LCPI6_3(%rip), %zmm6
	vmovdqa64	.LCPI6_4(%rip), %zmm7
	leaq	(%rax,%rax,2), %rax
	movabsq	$2305843009213693936, %rdx
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.5(%rip), %rsi
	movl	$2863078533, %r9d
	movq	%rsi, 112(%rsp)
	movq	8(%rcx), %rcx
	leaq	(%rcx,%rax,8), %rax
	movq	%rax, 64(%rsp)
	leaq	12(%rdx), %rax
	movq	%rax, 72(%rsp)
	jmp	.LBB6_29
	.p2align	4
.LBB6_28:
	movq	16(%rsp), %rcx
	movq	96(%rsp), %r13
	addq	$24, %rcx
	cmpq	64(%rsp), %rcx
	je	.LBB6_47
.LBB6_29:
	movq	16(%rcx), %r10
	testq	%r10, %r10
	je	.LBB6_85
	leaq	(%r10,%r10), %r11
	movq	%r13, %rax
	movq	%rcx, 16(%rsp)
	orq	%r11, %rax
	shrq	$32, %rax
	je	.LBB6_31
	movq	%r13, %rax
	xorl	%edx, %edx
	divq	%r11
	movq	%r13, %rax
	subq	%rdx, %rax
	cmpq	%rax, %r11
	ja	.LBB6_28
	jmp	.LBB6_34
	.p2align	4
.LBB6_31:
	movl	%r13d, %eax
	xorl	%edx, %edx
	divl	%r11d
	movq	%r13, %rax
	subq	%rdx, %rax
	cmpq	%rax, %r11
	ja	.LBB6_28
.LBB6_34:
	movq	16(%rsp), %rcx
	movq	32(%rsp), %rdi
	movq	%r10, %rsi
	movq	24(%rsp), %r13
	movq	%r10, %rbp
	shrq	$4, %rbp
	leaq	(,%r10,8), %r15
	shlq	$6, %rbp
	movq	8(%rcx), %rdx
	movabsq	$2305843009213693936, %rcx
	andq	%rcx, %rsi
	movq	%r10, %rcx
	andq	72(%rsp), %rcx
	movq	%rsi, 8(%rsp)
	leaq	(%rdi,%r10,4), %rsi
	jmp	.LBB6_35
	.p2align	4
.LBB6_46:
	subq	%r11, %rax
	addq	%r15, %rsi
	addq	%r15, %r13
	cmpq	%rax, %r11
	ja	.LBB6_28
.LBB6_35:
	cmpq	$4, %r10
	jae	.LBB6_37
	xorl	%r14d, %r14d
	jmp	.LBB6_45
	.p2align	4
.LBB6_37:
	cmpq	$16, %r10
	jae	.LBB6_39
	xorl	%r12d, %r12d
	jmp	.LBB6_43
	.p2align	4
.LBB6_39:
	xorl	%r14d, %r14d
	.p2align	4
.LBB6_40:
	vmovdqu64	(%r13,%r14), %zmm8
	vmovdqu64	(%rsi,%r14), %zmm9
	vpaddd	%zmm8, %zmm9, %zmm10
	vpsubd	%zmm9, %zmm8, %zmm8
	vpaddd	%zmm4, %zmm10, %zmm11
	vpmovd2m	%zmm11, %k1
	vmovdqa32	%zmm10, %zmm11 {%k1}
	vpmovd2m	%zmm8, %k1
	vpaddd	%zmm5, %zmm8, %zmm8 {%k1}
	vpmulld	(%rdx,%r14), %zmm8, %zmm8
	vmovdqu64	%zmm11, (%r13,%r14)
	vpshufd	$245, %zmm8, %zmm10
	vpmuludq	%zmm6, %zmm8, %zmm9
	vpmuludq	%zmm6, %zmm10, %zmm10
	vpermt2d	%zmm10, %zmm7, %zmm9
	vpsrld	$13, %zmm9, %zmm9
	vpmulld	%zmm5, %zmm9, %zmm9
	vpsubd	%zmm9, %zmm8, %zmm8
	vmovdqu64	%zmm8, (%rsi,%r14)
	addq	$64, %r14
	cmpq	%r14, %rbp
	jne	.LBB6_40
	cmpq	8(%rsp), %r10
	je	.LBB6_46
	movq	8(%rsp), %r14
	movq	%r14, %r12
	testb	$12, %r10b
	je	.LBB6_45
	.p2align	4
.LBB6_43:
	vmovdqu	(%r13,%r12,4), %xmm8
	vmovdqu	(%rsi,%r12,4), %xmm9
	vpaddd	%xmm8, %xmm9, %xmm10
	vpsubd	%xmm9, %xmm8, %xmm8
	vpaddd	%xmm0, %xmm10, %xmm11
	vpmovd2m	%xmm11, %k1
	vmovdqa32	%xmm10, %xmm11 {%k1}
	vpmovd2m	%xmm8, %k1
	vpaddd	%xmm1, %xmm8, %xmm8 {%k1}
	vpmulld	(%rdx,%r12,4), %xmm8, %xmm8
	vmovdqu	%xmm11, (%r13,%r12,4)
	vpshufd	$245, %xmm8, %xmm10
	vpmuludq	%xmm2, %xmm8, %xmm9
	vpmuludq	%xmm2, %xmm10, %xmm10
	vpermt2d	%xmm10, %xmm3, %xmm9
	vpsrld	$13, %xmm9, %xmm9
	vpmulld	%xmm1, %xmm9, %xmm9
	vpsubd	%xmm9, %xmm8, %xmm8
	vmovdqu	%xmm8, (%rsi,%r12,4)
	addq	$4, %r12
	cmpq	%r12, %rcx
	jne	.LBB6_43
	movq	%rcx, %r14
	cmpq	%rcx, %r10
	je	.LBB6_46
	.p2align	4
.LBB6_45:
	movl	(%r13,%r14,4), %r12d
	movl	(%rsi,%r14,4), %ebx
	leal	-12289(%rbx,%r12), %edi
	leal	(%rbx,%r12), %r8d
	testl	%edi, %edi
	cmovnsl	%edi, %r8d
	subl	%ebx, %r12d
	leal	12289(%r12), %edi
	testl	%r12d, %r12d
	cmovnsl	%r12d, %edi
	imull	(%rdx,%r14,4), %edi
	movl	%r8d, (%r13,%r14,4)
	movq	%rdi, %r8
	imulq	%r9, %r8
	shrq	$45, %r8
	imull	$12289, %r8d, %r8d
	subl	%r8d, %edi
	movl	%edi, (%rsi,%r14,4)
	incq	%r14
	cmpq	%r14, %r10
	jne	.LBB6_45
	jmp	.LBB6_46
.LBB6_47:
	movq	(%rsp), %rax
	movq	16(%rax), %rax
	testq	%rax, %rax
	je	.LBB6_68
	movq	(%rsp), %rcx
	leaq	(%rax,%rax,2), %rax
	movl	$2863078533, %r9d
	movq	8(%rcx), %rcx
	leaq	(%rcx,%rax,8), %rax
	movq	%rax, 64(%rsp)
	jmp	.LBB6_50
	.p2align	4
.LBB6_49:
	movq	16(%rsp), %rcx
	movq	96(%rsp), %r13
	addq	$24, %rcx
	cmpq	64(%rsp), %rcx
	je	.LBB6_68
.LBB6_50:
	movq	16(%rcx), %r10
	testq	%r10, %r10
	je	.LBB6_85
	leaq	(%r10,%r10), %r11
	movq	%r13, %rax
	movq	%rcx, 16(%rsp)
	orq	%r11, %rax
	shrq	$32, %rax
	je	.LBB6_52
	movq	%r13, %rax
	xorl	%edx, %edx
	divq	%r11
	movq	%r13, %rax
	subq	%rdx, %rax
	cmpq	%rax, %r11
	ja	.LBB6_49
	jmp	.LBB6_55
	.p2align	4
.LBB6_52:
	movl	%r13d, %eax
	xorl	%edx, %edx
	divl	%r11d
	movq	%r13, %rax
	subq	%rdx, %rax
	cmpq	%rax, %r11
	ja	.LBB6_49
.LBB6_55:
	movq	16(%rsp), %rcx
	movq	56(%rsp), %r13
	movq	%r10, %rsi
	movq	%r10, %rbp
	shrq	$4, %rbp
	leaq	(,%r10,8), %r15
	shlq	$6, %rbp
	movq	8(%rcx), %rdx
	movabsq	$2305843009213693936, %rcx
	andq	%rcx, %rsi
	movq	%r10, %rcx
	andq	72(%rsp), %rcx
	movq	%rsi, 8(%rsp)
	leaq	(%r13,%r10,4), %rsi
	jmp	.LBB6_56
	.p2align	4
.LBB6_67:
	subq	%r11, %rax
	addq	%r15, %rsi
	addq	%r15, %r13
	cmpq	%rax, %r11
	ja	.LBB6_49
.LBB6_56:
	cmpq	$4, %r10
	jae	.LBB6_58
	xorl	%r14d, %r14d
	jmp	.LBB6_66
	.p2align	4
.LBB6_58:
	cmpq	$16, %r10
	jae	.LBB6_60
	xorl	%r12d, %r12d
	jmp	.LBB6_64
	.p2align	4
.LBB6_60:
	xorl	%r14d, %r14d
	.p2align	4
.LBB6_61:
	vmovdqu64	(%r13,%r14), %zmm8
	vmovdqu64	(%rsi,%r14), %zmm9
	vpaddd	%zmm8, %zmm9, %zmm10
	vpsubd	%zmm9, %zmm8, %zmm8
	vpaddd	%zmm4, %zmm10, %zmm11
	vpmovd2m	%zmm11, %k1
	vmovdqa32	%zmm10, %zmm11 {%k1}
	vpmovd2m	%zmm8, %k1
	vpaddd	%zmm5, %zmm8, %zmm8 {%k1}
	vpmulld	(%rdx,%r14), %zmm8, %zmm8
	vmovdqu64	%zmm11, (%r13,%r14)
	vpshufd	$245, %zmm8, %zmm10
	vpmuludq	%zmm6, %zmm8, %zmm9
	vpmuludq	%zmm6, %zmm10, %zmm10
	vpermt2d	%zmm10, %zmm7, %zmm9
	vpsrld	$13, %zmm9, %zmm9
	vpmulld	%zmm5, %zmm9, %zmm9
	vpsubd	%zmm9, %zmm8, %zmm8
	vmovdqu64	%zmm8, (%rsi,%r14)
	addq	$64, %r14
	cmpq	%r14, %rbp
	jne	.LBB6_61
	cmpq	8(%rsp), %r10
	je	.LBB6_67
	movq	8(%rsp), %r14
	movq	%r14, %r12
	testb	$12, %r10b
	je	.LBB6_66
	.p2align	4
.LBB6_64:
	vmovdqu	(%r13,%r12,4), %xmm8
	vmovdqu	(%rsi,%r12,4), %xmm9
	vpaddd	%xmm8, %xmm9, %xmm10
	vpsubd	%xmm9, %xmm8, %xmm8
	vpaddd	%xmm0, %xmm10, %xmm11
	vpmovd2m	%xmm11, %k1
	vmovdqa32	%xmm10, %xmm11 {%k1}
	vpmovd2m	%xmm8, %k1
	vpaddd	%xmm1, %xmm8, %xmm8 {%k1}
	vpmulld	(%rdx,%r12,4), %xmm8, %xmm8
	vmovdqu	%xmm11, (%r13,%r12,4)
	vpshufd	$245, %xmm8, %xmm10
	vpmuludq	%xmm2, %xmm8, %xmm9
	vpmuludq	%xmm2, %xmm10, %xmm10
	vpermt2d	%xmm10, %xmm3, %xmm9
	vpsrld	$13, %xmm9, %xmm9
	vpmulld	%xmm1, %xmm9, %xmm9
	vpsubd	%xmm9, %xmm8, %xmm8
	vmovdqu	%xmm8, (%rsi,%r12,4)
	addq	$4, %r12
	cmpq	%r12, %rcx
	jne	.LBB6_64
	movq	%rcx, %r14
	cmpq	%rcx, %r10
	je	.LBB6_67
	.p2align	4
.LBB6_66:
	movl	(%r13,%r14,4), %ebx
	movl	(%rsi,%r14,4), %r12d
	leal	-12289(%r12,%rbx), %edi
	leal	(%r12,%rbx), %r8d
	testl	%edi, %edi
	cmovnsl	%edi, %r8d
	subl	%r12d, %ebx
	leal	12289(%rbx), %edi
	testl	%ebx, %ebx
	cmovnsl	%ebx, %edi
	imull	(%rdx,%r14,4), %edi
	movl	%r8d, (%r13,%r14,4)
	movq	%rdi, %r8
	imulq	%r9, %r8
	shrq	$45, %r8
	imull	$12289, %r8d, %r8d
	subl	%r8d, %edi
	movl	%edi, (%rsi,%r14,4)
	incq	%r14
	cmpq	%r14, %r10
	jne	.LBB6_66
	jmp	.LBB6_67
.LBB6_68:
	movq	48(%rsp), %rdx
	movabsq	$9223372036854775800, %rsi
	cmpq	$4, %rdx
	jae	.LBB6_70
	movq	80(%rsp), %rbx
	movq	24(%rsp), %rdi
	movq	56(%rsp), %r8
	xorl	%eax, %eax
	jmp	.LBB6_79
.LBB6_70:
	movq	80(%rsp), %rbx
	movq	24(%rsp), %rdi
	movq	56(%rsp), %r8
	cmpq	$32, %rdx
	jae	.LBB6_72
	xorl	%eax, %eax
	jmp	.LBB6_76
.LBB6_72:
	vpbroadcastd	.LCPI6_3(%rip), %zmm0
	vmovdqa64	.LCPI6_4(%rip), %zmm1
	vpbroadcastd	.LCPI6_5(%rip), %zmm2
	leaq	-56(%rsi), %rax
	xorl	%ecx, %ecx
	andq	%r13, %rax
	.p2align	4
.LBB6_73:
	vmovdqu64	(%r8,%rcx,4), %zmm3
	vmovdqu64	64(%r8,%rcx,4), %zmm4
	vmovdqu64	128(%r8,%rcx,4), %zmm5
	vmovdqu64	192(%r8,%rcx,4), %zmm6
	vpmulld	(%rdi,%rcx,4), %zmm3, %zmm3
	vpmulld	64(%rdi,%rcx,4), %zmm4, %zmm4
	vpmulld	128(%rdi,%rcx,4), %zmm5, %zmm5
	vpmulld	192(%rdi,%rcx,4), %zmm6, %zmm6
	vpshufd	$245, %zmm3, %zmm8
	vpmuludq	%zmm0, %zmm3, %zmm7
	vpmuludq	%zmm0, %zmm4, %zmm9
	vpmuludq	%zmm0, %zmm5, %zmm10
	vpmuludq	%zmm0, %zmm8, %zmm8
	vpermt2d	%zmm8, %zmm1, %zmm7
	vpshufd	$245, %zmm4, %zmm8
	vpmuludq	%zmm0, %zmm8, %zmm8
	vpermt2d	%zmm8, %zmm1, %zmm9
	vpshufd	$245, %zmm5, %zmm8
	vpsrld	$13, %zmm7, %zmm7
	vpmuludq	%zmm0, %zmm8, %zmm8
	vpmulld	%zmm2, %zmm7, %zmm7
	vpermt2d	%zmm8, %zmm1, %zmm10
	vpshufd	$245, %zmm6, %zmm8
	vpsubd	%zmm7, %zmm3, %zmm3
	vpsrld	$13, %zmm9, %zmm7
	vpmuludq	%zmm0, %zmm6, %zmm9
	vpmuludq	%zmm0, %zmm8, %zmm8
	vpmulld	%zmm2, %zmm7, %zmm7
	vmovdqu64	%zmm3, (%rdi,%rcx,4)
	vpermt2d	%zmm8, %zmm1, %zmm9
	vpsubd	%zmm7, %zmm4, %zmm4
	vpsrld	$13, %zmm10, %zmm7
	vpmulld	%zmm2, %zmm7, %zmm7
	vmovdqu64	%zmm4, 64(%rdi,%rcx,4)
	vpsubd	%zmm7, %zmm5, %zmm5
	vpsrld	$13, %zmm9, %zmm7
	vpmulld	%zmm2, %zmm7, %zmm7
	vmovdqu64	%zmm5, 128(%rdi,%rcx,4)
	vpsubd	%zmm7, %zmm6, %zmm6
	vmovdqu64	%zmm6, 192(%rdi,%rcx,4)
	addq	$64, %rcx
	cmpq	%rcx, %rax
	jne	.LBB6_73
	cmpq	%rax, %r13
	je	.LBB6_81
	testb	$28, %dl
	je	.LBB6_79
.LBB6_76:
	vpbroadcastd	.LCPI6_3(%rip), %ymm0
	vmovdqa	.LCPI6_8(%rip), %ymm1
	vpbroadcastd	.LCPI6_5(%rip), %ymm2
	movq	%rax, %rcx
	movq	%r13, %rax
	andq	%rsi, %rax
	.p2align	4
.LBB6_77:
	vmovdqu	(%r8,%rcx,4), %ymm3
	vpmulld	(%rdi,%rcx,4), %ymm3, %ymm3
	vpshufd	$245, %ymm3, %ymm5
	vpmuludq	%ymm0, %ymm3, %ymm4
	vpmuludq	%ymm0, %ymm5, %ymm5
	vpermt2d	%ymm5, %ymm1, %ymm4
	vpsrld	$13, %ymm4, %ymm4
	vpmulld	%ymm2, %ymm4, %ymm4
	vpsubd	%ymm4, %ymm3, %ymm3
	vmovdqu	%ymm3, (%rdi,%rcx,4)
	addq	$8, %rcx
	cmpq	%rcx, %rax
	jne	.LBB6_77
	cmpq	%rax, %r13
	je	.LBB6_81
.LBB6_79:
	movl	$2863078533, %ecx
	.p2align	4
.LBB6_80:
	movl	(%r8,%rax,4), %edx
	imull	(%rdi,%rax,4), %edx
	movq	%rdx, %rsi
	imulq	%rcx, %rsi
	shrq	$45, %rsi
	imull	$12289, %esi, %esi
	subl	%esi, %edx
	movl	%edx, (%rdi,%rax,4)
	incq	%rax
	cmpq	%rax, %r13
	jne	.LBB6_80
.LBB6_81:
	movq	(%rsp), %rax
	movq	40(%rax), %rax
	testq	%rax, %rax
	je	.LBB6_101
	movq	(%rsp), %rcx
	vpbroadcastd	.LCPI6_3(%rip), %xmm0
	vpmovsxbd	.LCPI6_11(%rip), %xmm1
	vpbroadcastd	.LCPI6_5(%rip), %xmm2
	vpbroadcastd	.LCPI6_6(%rip), %xmm3
	vpbroadcastd	.LCPI6_3(%rip), %zmm4
	vmovdqa64	.LCPI6_4(%rip), %zmm5
	vpbroadcastd	.LCPI6_5(%rip), %zmm6
	vpbroadcastd	.LCPI6_6(%rip), %zmm7
	leaq	(%rax,%rax,2), %rax
	movabsq	$2305843009213693936, %rdx
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.6(%rip), %rsi
	movl	$2863078533, %r10d
	movq	%rsi, 112(%rsp)
	movq	32(%rcx), %rcx
	leaq	(%rcx,%rax,8), %rax
	movq	%rax, 64(%rsp)
	leaq	12(%rdx), %rax
	movq	%rax, 72(%rsp)
	jmp	.LBB6_84
	.p2align	4
.LBB6_83:
	movq	16(%rsp), %rcx
	movq	80(%rsp), %rbx
	movq	96(%rsp), %r13
	addq	$24, %rcx
	cmpq	64(%rsp), %rcx
	je	.LBB6_101
.LBB6_84:
	movq	16(%rcx), %r11
	testq	%r11, %r11
	je	.LBB6_85
	leaq	(%r11,%r11), %r12
	movq	%r13, %rax
	movq	%rcx, 16(%rsp)
	orq	%r12, %rax
	shrq	$32, %rax
	je	.LBB6_87
	movq	%r13, %rax
	xorl	%edx, %edx
	divq	%r12
	movq	%r13, %rax
	subq	%rdx, %rax
	cmpq	%rax, %r12
	ja	.LBB6_83
	jmp	.LBB6_90
	.p2align	4
.LBB6_87:
	movl	%r13d, %eax
	xorl	%edx, %edx
	divl	%r12d
	movq	%r13, %rax
	subq	%rdx, %rax
	cmpq	%rax, %r12
	ja	.LBB6_83
.LBB6_90:
	movq	16(%rsp), %rcx
	movq	32(%rsp), %rdi
	movabsq	$2305843009213693936, %r8
	movq	%r11, %rsi
	movq	24(%rsp), %r14
	movq	%r11, %r9
	shrq	$4, %r9
	leaq	(,%r11,8), %r13
	andq	%r8, %rsi
	shlq	$6, %r9
	movq	%rsi, 8(%rsp)
	movq	%r11, %rsi
	andq	72(%rsp), %rsi
	movq	8(%rcx), %rdx
	leaq	(%rdi,%r11,4), %r15
	jmp	.LBB6_91
	.p2align	4
.LBB6_100:
	subq	%r12, %rax
	addq	%r13, %r15
	addq	%r13, %r14
	cmpq	%rax, %r12
	ja	.LBB6_83
.LBB6_91:
	cmpq	$4, %r11
	jae	.LBB6_93
	xorl	%ebp, %ebp
	jmp	.LBB6_99
	.p2align	4
.LBB6_93:
	xorl	%ecx, %ecx
	cmpq	$16, %r11
	jb	.LBB6_97
	.p2align	4
.LBB6_94:
	vmovdqu64	(%r15,%rcx), %zmm8
	vmovdqu64	(%r14,%rcx), %zmm11
	vpmulld	(%rdx,%rcx), %zmm8, %zmm8
	vpshufd	$245, %zmm8, %zmm10
	vpmuludq	%zmm4, %zmm8, %zmm9
	vpmuludq	%zmm4, %zmm10, %zmm10
	vpermt2d	%zmm10, %zmm5, %zmm9
	vpsrld	$13, %zmm9, %zmm9
	vpmulld	%zmm6, %zmm9, %zmm9
	vpsubd	%zmm9, %zmm8, %zmm8
	vpsubd	%zmm8, %zmm11, %zmm10
	vpaddd	%zmm11, %zmm8, %zmm8
	vpmovd2m	%zmm10, %k1
	vpaddd	%zmm7, %zmm8, %zmm9
	vpaddd	%zmm6, %zmm10, %zmm10 {%k1}
	vpmovd2m	%zmm9, %k1
	vmovdqu64	%zmm10, (%r15,%rcx)
	vmovdqa32	%zmm8, %zmm9 {%k1}
	vmovdqu64	%zmm9, (%r14,%rcx)
	addq	$64, %rcx
	cmpq	%rcx, %r9
	jne	.LBB6_94
	cmpq	8(%rsp), %r11
	je	.LBB6_100
	movq	8(%rsp), %rbp
	movq	%rbp, %rcx
	testb	$12, %r11b
	je	.LBB6_99
	.p2align	4
.LBB6_97:
	vmovdqu	(%r15,%rcx,4), %xmm8
	vpmulld	(%rdx,%rcx,4), %xmm8, %xmm8
	vpshufd	$245, %xmm8, %xmm10
	vpmuludq	%xmm0, %xmm8, %xmm9
	vpmuludq	%xmm0, %xmm10, %xmm10
	vpermt2d	%xmm10, %xmm1, %xmm9
	vpsrld	$13, %xmm9, %xmm9
	vpmulld	%xmm2, %xmm9, %xmm9
	vpsubd	%xmm9, %xmm8, %xmm8
	vmovdqu	(%r14,%rcx,4), %xmm9
	vpsubd	%xmm8, %xmm9, %xmm10
	vpaddd	%xmm9, %xmm8, %xmm8
	vpmovd2m	%xmm10, %k1
	vpaddd	%xmm3, %xmm8, %xmm9
	vpaddd	%xmm2, %xmm10, %xmm10 {%k1}
	vpmovd2m	%xmm9, %k1
	vmovdqu	%xmm10, (%r15,%rcx,4)
	vmovdqa32	%xmm8, %xmm9 {%k1}
	vmovdqu	%xmm9, (%r14,%rcx,4)
	addq	$4, %rcx
	cmpq	%rcx, %rsi
	jne	.LBB6_97
	movq	%rsi, %rbp
	cmpq	%rsi, %r11
	je	.LBB6_100
	.p2align	4
.LBB6_99:
	movl	(%r15,%rbp,4), %ecx
	movl	(%r14,%rbp,4), %edi
	imull	(%rdx,%rbp,4), %ecx
	movq	%rcx, %rbx
	imulq	%r10, %rbx
	shrq	$45, %rbx
	imull	$12289, %ebx, %ebx
	subl	%ebx, %ecx
	movl	%edi, %ebx
	subl	%ecx, %ebx
	leal	12289(%rbx), %r8d
	testl	%ebx, %ebx
	cmovnsl	%ebx, %r8d
	movl	%r8d, (%r15,%rbp,4)
	movl	%ecx, %r8d
	addl	%edi, %ecx
	leal	-12289(%rdi,%r8), %edi
	testl	%edi, %edi
	cmovnsl	%edi, %ecx
	movl	%ecx, (%r14,%rbp,4)
	incq	%rbp
	cmpq	%rbp, %r11
	jne	.LBB6_99
	jmp	.LBB6_100
.LBB6_101:
	movq	(%rsp), %rax
	movq	48(%rsp), %r10
	movq	24(%rsp), %r9
	movq	32(%rsp), %r11
	movl	48(%rax), %eax
	leaq	(,%r10,8), %r8
	movq	%r9, %rdi
	leaq	-4(%r8), %rdx
	cmpq	$28, %rdx
	jb	.LBB6_112
	movq	%rdx, %rcx
	shrq	$2, %rcx
	incq	%rcx
	cmpq	$252, %rdx
	jae	.LBB6_107
	xorl	%edx, %edx
	jmp	.LBB6_104
.LBB6_107:
	vpbroadcastd	.LCPI6_3(%rip), %zmm1
	vmovdqa64	.LCPI6_4(%rip), %zmm2
	vpbroadcastd	.LCPI6_5(%rip), %zmm3
	movabsq	$9223372036854775800, %rdx
	vpbroadcastd	%eax, %zmm0
	xorl	%edi, %edi
	addq	$-56, %rdx
	andq	%rcx, %rdx
	.p2align	4
.LBB6_108:
	vpmulld	(%r9,%rdi,4), %zmm0, %zmm4
	vpmulld	64(%r9,%rdi,4), %zmm0, %zmm5
	vpmulld	128(%r9,%rdi,4), %zmm0, %zmm6
	vpmulld	192(%r9,%rdi,4), %zmm0, %zmm7
	vpshufd	$245, %zmm4, %zmm9
	vpmuludq	%zmm1, %zmm4, %zmm8
	vpmuludq	%zmm1, %zmm5, %zmm10
	vpmuludq	%zmm1, %zmm6, %zmm11
	vpmuludq	%zmm1, %zmm9, %zmm9
	vpermt2d	%zmm9, %zmm2, %zmm8
	vpshufd	$245, %zmm5, %zmm9
	vpmuludq	%zmm1, %zmm9, %zmm9
	vpermt2d	%zmm9, %zmm2, %zmm10
	vpshufd	$245, %zmm6, %zmm9
	vpsrld	$13, %zmm8, %zmm8
	vpmuludq	%zmm1, %zmm9, %zmm9
	vpmulld	%zmm3, %zmm8, %zmm8
	vpermt2d	%zmm9, %zmm2, %zmm11
	vpshufd	$245, %zmm7, %zmm9
	vpsubd	%zmm8, %zmm4, %zmm4
	vpsrld	$13, %zmm10, %zmm8
	vpmuludq	%zmm1, %zmm7, %zmm10
	vpmuludq	%zmm1, %zmm9, %zmm9
	vpmulld	%zmm3, %zmm8, %zmm8
	vmovdqu64	%zmm4, (%r9,%rdi,4)
	vpermt2d	%zmm9, %zmm2, %zmm10
	vpsubd	%zmm8, %zmm5, %zmm5
	vpsrld	$13, %zmm11, %zmm8
	vpmulld	%zmm3, %zmm8, %zmm8
	vmovdqu64	%zmm5, 64(%r9,%rdi,4)
	vpsubd	%zmm8, %zmm6, %zmm6
	vpsrld	$13, %zmm10, %zmm8
	vpmulld	%zmm3, %zmm8, %zmm8
	vmovdqu64	%zmm6, 128(%r9,%rdi,4)
	vpsubd	%zmm8, %zmm7, %zmm7
	vmovdqu64	%zmm7, 192(%r9,%rdi,4)
	addq	$64, %rdi
	cmpq	%rdi, %rdx
	jne	.LBB6_108
	cmpq	%rdx, %rcx
	je	.LBB6_114
	testb	$56, %cl
	je	.LBB6_111
.LBB6_104:
	vpbroadcastd	.LCPI6_3(%rip), %ymm1
	vmovdqa	.LCPI6_8(%rip), %ymm2
	vpbroadcastd	.LCPI6_5(%rip), %ymm3
	movabsq	$9223372036854775800, %rdi
	movq	%rcx, %rsi
	vpbroadcastd	%eax, %ymm0
	andq	%rdi, %rsi
	leaq	(%r11,%rsi,4), %rdi
	.p2align	4
.LBB6_105:
	vpmulld	(%r9,%rdx,4), %ymm0, %ymm4
	vpshufd	$245, %ymm4, %ymm6
	vpmuludq	%ymm1, %ymm4, %ymm5
	vpmuludq	%ymm1, %ymm6, %ymm6
	vpermt2d	%ymm6, %ymm2, %ymm5
	vpsrld	$13, %ymm5, %ymm5
	vpmulld	%ymm3, %ymm5, %ymm5
	vpsubd	%ymm5, %ymm4, %ymm4
	vmovdqu	%ymm4, (%r9,%rdx,4)
	addq	$8, %rdx
	cmpq	%rdx, %rsi
	jne	.LBB6_105
	cmpq	%rsi, %rcx
	je	.LBB6_114
.LBB6_112:
	addq	%r8, %r11
	movl	$2863078533, %ecx
	.p2align	4
.LBB6_113:
	movl	(%rdi), %edx
	imull	%eax, %edx
	movq	%rdx, %rsi
	imulq	%rcx, %rsi
	shrq	$45, %rsi
	imull	$12289, %esi, %esi
	subl	%esi, %edx
	movl	%edx, (%rdi)
	addq	$4, %rdi
	cmpq	%r11, %rdi
	jne	.LBB6_113
.LBB6_114:
	movabsq	$9223372036854775800, %rdx
	cmpq	$4, %r10
	jae	.LBB6_116
	xorl	%eax, %eax
	jmp	.LBB6_125
.LBB6_116:
	cmpq	$16, %r10
	jae	.LBB6_118
	xorl	%eax, %eax
	jmp	.LBB6_122
.LBB6_118:
	leaq	-24(%rdx), %rax
	xorl	%ecx, %ecx
	andq	%r13, %rax
	.p2align	4
.LBB6_119:
	vpmovzxdq	(%r9,%rcx,4), %zmm0
	vpmovzxdq	32(%r9,%rcx,4), %zmm1
	vpmovzxdq	64(%r9,%rcx,4), %zmm2
	vpmovzxdq	96(%r9,%rcx,4), %zmm3
	vmovdqu64	%zmm0, (%rbx,%rcx,8)
	vmovdqu64	%zmm1, 64(%rbx,%rcx,8)
	vmovdqu64	%zmm2, 128(%rbx,%rcx,8)
	vmovdqu64	%zmm3, 192(%rbx,%rcx,8)
	addq	$32, %rcx
	cmpq	%rcx, %rax
	jne	.LBB6_119
	cmpq	%rax, %r13
	je	.LBB6_126
	testb	$12, %r10b
	je	.LBB6_125
.LBB6_122:
	andq	%r13, %rdx
	.p2align	4
.LBB6_123:
	vpmovzxdq	(%r9,%rax,4), %zmm0
	vmovdqu64	%zmm0, (%rbx,%rax,8)
	addq	$8, %rax
	cmpq	%rax, %rdx
	jne	.LBB6_123
	movq	%rdx, %rax
	cmpq	%rdx, %r13
	je	.LBB6_126
	.p2align	4
.LBB6_125:
	movl	(%r9,%rax,4), %ecx
	movq	%rcx, (%rbx,%rax,8)
	incq	%rax
	cmpq	%rax, %r13
	jne	.LBB6_125
.LBB6_126:
	movq	%r10, %rax
	shrq	$60, %rax
	je	.LBB6_131
	xorl	%r12d, %r12d
.LBB6_128:
.Ltmp13:
	movq	40(%rsp), %rsi
	movq	%r12, %rdi
	vzeroupper
	callq	*_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp14:
	jmp	.LBB6_10
.LBB6_131:
	testq	%r10, %r10
	je	.LBB6_132
	vzeroupper
	callq	*_RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movq	40(%rsp), %rdi
	movl	$8, %esi
	movl	$8, %r12d
	callq	*_RNvCs1njKG4L9aB3_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB6_128
	movq	%rax, %rdi
	movq	%r13, %rax
	jmp	.LBB6_135
.LBB6_132:
	movl	$8, %edi
	xorl	%eax, %eax
.LBB6_135:
	movq	120(%rsp), %r15
	movq	40(%rsp), %r14
	movq	%rbx, %rsi
	movq	%rbx, %r12
	movq	%rax, (%r15)
	movq	%r14, %rdx
	movq	%rdi, 8(%r15)
	vzeroupper
	callq	*memcpy@GOTPCREL(%rip)
	movq	_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip), %rbx
	movl	$8, %edx
	movq	%r13, 16(%r15)
	movq	%r12, %rdi
	movq	%r14, %rsi
	callq	*%rbx
	movq	88(%rsp), %r14
	movq	24(%rsp), %rdi
	movl	$4, %edx
	movq	%r14, %rsi
	callq	*%rbx
	movq	56(%rsp), %rdi
	movl	$4, %edx
	movq	%r14, %rsi
	callq	*%rbx
	movq	%r15, %rax
	addq	$216, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB6_85:
	.cfi_def_cfa_offset 272
.Ltmp11:
	movq	112(%rsp), %rdx
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.11(%rip), %rdi
	movl	$55, %esi
	vzeroupper
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking9panic_fmt@GOTPCREL(%rip)
.Ltmp12:
	jmp	.LBB6_10
.LBB6_111:
	leaq	(%r11,%rdx,4), %rdi
	jmp	.LBB6_112
.LBB6_6:
	movq	(%rsp), %rdi
	leaq	104(%rsp), %rsi
	callq	_RINvMNtNtCs9k3SxhrAWiO_3std4sync9once_lockINtB3_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB2_11get_or_initNCNvMBV_NtBV_19PolynomialWorkspace3new0E0zEBV_
	movq	48(%rsp), %rdx
	jmp	.LBB6_7
.LBB6_24:
.Ltmp9:
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.9(%rip), %r9
	leaq	104(%rsp), %rsi
	leaq	128(%rsp), %rdx
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	callq	*_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedjjEB4_@GOTPCREL(%rip)
.Ltmp10:
	jmp	.LBB6_10
.LBB6_2:
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.7(%rip), %rdi
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.8(%rip), %rdx
	movl	$73, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking9panic_fmt@GOTPCREL(%rip)
.LBB6_21:
.Ltmp15:
	leaq	.Lanon.266f1d35eff140d801b77b99e32e07c5.10(%rip), %rdx
	movq	%r13, %rdi
	movq	%r13, %rsi
	vzeroupper
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp16:
	jmp	.LBB6_10
.LBB6_136:
	movq	40(%rsp), %rsi
	movl	$8, %edi
	callq	*_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.LBB6_9:
.Ltmp21:
	movl	$4, %edi
	movq	%r14, %rsi
	callq	*_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp22:
	jmp	.LBB6_10
.LBB6_13:
.Ltmp18:
	movq	88(%rsp), %rsi
	movl	$4, %edi
	callq	*_RNvNtCs6i54tJFfzR_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp19:
.LBB6_10:
	ud2
.LBB6_14:
.Ltmp20:
	movq	24(%rsp), %rdi
	movq	88(%rsp), %rsi
	movl	$4, %edx
	movq	%rax, %r14
	callq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB6_15
.LBB6_11:
.Ltmp23:
	movq	%rax, %r14
.LBB6_15:
	movq	80(%rsp), %rdi
	movq	40(%rsp), %rsi
	movl	$8, %edx
	callq	*_RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.LBB6_129:
.Ltmp17:
	leaq	136(%rsp), %rdi
	movq	%rax, %r14
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtCsbitZm3QGn75_12ntt_assembly19PolynomialWorkspaceEBD_
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end6:
	.size	review_ntt_product, .Lfunc_end6-review_ntt_product
	.cfi_endproc
	.section	.gcc_except_table.review_ntt_product,"a",@progbits
	.p2align	2, 0x0
GCC_except_table6:
.Lexception1:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end1-.Lcst_begin1
.Lcst_begin1:
	.uleb128 .Lfunc_begin1-.Lfunc_begin1
	.uleb128 .Ltmp13-.Lfunc_begin1
	.byte	0
	.byte	0
	.uleb128 .Ltmp13-.Lfunc_begin1
	.uleb128 .Ltmp14-.Ltmp13
	.uleb128 .Ltmp17-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp14-.Lfunc_begin1
	.uleb128 .Ltmp11-.Ltmp14
	.byte	0
	.byte	0
	.uleb128 .Ltmp11-.Lfunc_begin1
	.uleb128 .Ltmp12-.Ltmp11
	.uleb128 .Ltmp17-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp12-.Lfunc_begin1
	.uleb128 .Ltmp9-.Ltmp12
	.byte	0
	.byte	0
	.uleb128 .Ltmp9-.Lfunc_begin1
	.uleb128 .Ltmp10-.Ltmp9
	.uleb128 .Ltmp17-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp10-.Lfunc_begin1
	.uleb128 .Ltmp15-.Ltmp10
	.byte	0
	.byte	0
	.uleb128 .Ltmp15-.Lfunc_begin1
	.uleb128 .Ltmp16-.Ltmp15
	.uleb128 .Ltmp17-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp16-.Lfunc_begin1
	.uleb128 .Ltmp21-.Ltmp16
	.byte	0
	.byte	0
	.uleb128 .Ltmp21-.Lfunc_begin1
	.uleb128 .Ltmp22-.Ltmp21
	.uleb128 .Ltmp23-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp18-.Lfunc_begin1
	.uleb128 .Ltmp19-.Ltmp18
	.uleb128 .Ltmp20-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp19-.Lfunc_begin1
	.uleb128 .Lfunc_end6-.Ltmp19
	.byte	0
	.byte	0
.Lcst_end1:
	.p2align	2, 0x0

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.0,@object
	.section	.data.rel.ro..Lanon.266f1d35eff140d801b77b99e32e07c5.0,"aw",@progbits
	.p2align	3, 0x0
.Lanon.266f1d35eff140d801b77b99e32e07c5.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtBd_4Once15call_once_forceNCINvMNtBf_9once_lockINtB1g_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1f_11get_or_initNCNvMB1N_NtB1N_19PolynomialWorkspace3new0E0zE0E0INtNtNtCsgxBkk5gSRhY_4core3ops8function6FnOnceTRNtBd_9OnceStateEE9call_once6vtableB1N_
	.quad	_RNCINvMs0_NtNtCs9k3SxhrAWiO_3std4sync4onceNtB8_4Once15call_once_forceNCINvMNtBa_9once_lockINtB1b_8OnceLockNtCsbitZm3QGn75_12ntt_assembly9NttTablesE10initializeNCINvB1a_11get_or_initNCNvMB1I_NtB1I_19PolynomialWorkspace3new0E0zE0E0B1I_
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.0, 40

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.1,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.266f1d35eff140d801b77b99e32e07c5.1:
	.asciz	"/home/john-wu/.rustup/toolchains/1.98.1-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/std/src/sync/once.rs"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.1, 115

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.2,@object
	.section	.data.rel.ro..Lanon.266f1d35eff140d801b77b99e32e07c5.2,"aw",@progbits
	.p2align	3, 0x0
.Lanon.266f1d35eff140d801b77b99e32e07c5.2:
	.quad	.Lanon.266f1d35eff140d801b77b99e32e07c5.1
	.asciz	"r\000\000\000\000\000\000\000\342\000\000\000\024\000\000"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.2, 24

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.3,@object
	.section	.data.rel.ro..Lanon.266f1d35eff140d801b77b99e32e07c5.3,"aw",@progbits
	.p2align	3, 0x0
.Lanon.266f1d35eff140d801b77b99e32e07c5.3:
	.quad	.Lanon.266f1d35eff140d801b77b99e32e07c5.1
	.asciz	"r\000\000\000\000\000\000\000\342\000\000\0001\000\000"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.3, 24

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.4,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.266f1d35eff140d801b77b99e32e07c5.4:
	.asciz	"/tmp/bitz-falcon-grinding-review/ntt_assembly.rs"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.4, 49

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.5,@object
	.section	.data.rel.ro..Lanon.266f1d35eff140d801b77b99e32e07c5.5,"aw",@progbits
	.p2align	3, 0x0
.Lanon.266f1d35eff140d801b77b99e32e07c5.5:
	.quad	.Lanon.266f1d35eff140d801b77b99e32e07c5.4
	.asciz	"0\000\000\000\000\000\000\000z\000\000\000\035\000\000"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.5, 24

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.6,@object
	.section	.data.rel.ro..Lanon.266f1d35eff140d801b77b99e32e07c5.6,"aw",@progbits
	.p2align	3, 0x0
.Lanon.266f1d35eff140d801b77b99e32e07c5.6:
	.quad	.Lanon.266f1d35eff140d801b77b99e32e07c5.4
	.asciz	"0\000\000\000\000\000\000\000\212\000\000\000\035\000\000"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.6, 24

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.7,@object
	.section	.rodata..Lanon.266f1d35eff140d801b77b99e32e07c5.7,"a",@progbits
.Lanon.266f1d35eff140d801b77b99e32e07c5.7:
	.ascii	"unsupported Falcon polynomial degree"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.7, 36

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.8,@object
	.section	.data.rel.ro..Lanon.266f1d35eff140d801b77b99e32e07c5.8,"aw",@progbits
	.p2align	3, 0x0
.Lanon.266f1d35eff140d801b77b99e32e07c5.8:
	.quad	.Lanon.266f1d35eff140d801b77b99e32e07c5.4
	.asciz	"0\000\000\000\000\000\000\000\030\000\000\000\022\000\000"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.8, 24

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.9,@object
	.section	.data.rel.ro..Lanon.266f1d35eff140d801b77b99e32e07c5.9,"aw",@progbits
	.p2align	3, 0x0
.Lanon.266f1d35eff140d801b77b99e32e07c5.9:
	.quad	.Lanon.266f1d35eff140d801b77b99e32e07c5.4
	.asciz	"0\000\000\000\000\000\000\000'\000\000\000\t\000\000"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.9, 24

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.10,@object
	.section	.data.rel.ro..Lanon.266f1d35eff140d801b77b99e32e07c5.10,"aw",@progbits
	.p2align	3, 0x0
.Lanon.266f1d35eff140d801b77b99e32e07c5.10:
	.quad	.Lanon.266f1d35eff140d801b77b99e32e07c5.4
	.asciz	"0\000\000\000\000\000\000\000*\000\000\000\021\000\000"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.10, 24

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.11,@object
	.section	.rodata..Lanon.266f1d35eff140d801b77b99e32e07c5.11,"a",@progbits
.Lanon.266f1d35eff140d801b77b99e32e07c5.11:
	.ascii	"chunk size must be non-zero"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.11, 27

	.type	.Lanon.266f1d35eff140d801b77b99e32e07c5.12,@object
	.section	.data.rel.ro..Lanon.266f1d35eff140d801b77b99e32e07c5.12,"aw",@progbits
	.p2align	3, 0x0
.Lanon.266f1d35eff140d801b77b99e32e07c5.12:
	.quad	.Lanon.266f1d35eff140d801b77b99e32e07c5.4
	.asciz	"0\000\000\000\000\000\000\000F\000\000\000\036\000\000"
	.size	.Lanon.266f1d35eff140d801b77b99e32e07c5.12, 24

	.type	_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new10TABLES_512,@object
	.section	.data._RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new10TABLES_512,"aw",@progbits
	.p2align	3, 0x0
_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new10TABLES_512:
	.zero	56
	.asciz	"\003\000\000"
	.zero	4
	.size	_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new10TABLES_512, 64

	.type	_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new11TABLES_1024,@object
	.section	.data._RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new11TABLES_1024,"aw",@progbits
	.p2align	3, 0x0
_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new11TABLES_1024:
	.zero	56
	.asciz	"\003\000\000"
	.zero	4
	.size	_RNvNvMCsbitZm3QGn75_12ntt_assemblyNtB4_19PolynomialWorkspace3new11TABLES_1024, 64

	.hidden	DW.ref.rust_eh_personality
	.weak	DW.ref.rust_eh_personality
	.section	.data.DW.ref.rust_eh_personality,"awG",@progbits,DW.ref.rust_eh_personality,comdat
	.p2align	3, 0x0
	.type	DW.ref.rust_eh_personality,@object
	.size	DW.ref.rust_eh_personality, 8
DW.ref.rust_eh_personality:
	.quad	rust_eh_personality
	.ident	"rustc version 1.98.1 (48a229cea 2026-09-01)"
	.section	".note.GNU-stack","",@progbits
