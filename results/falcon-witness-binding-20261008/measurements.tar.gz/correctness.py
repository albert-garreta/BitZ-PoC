#!/usr/bin/env python3
"""Untimed complete-proof equality, including padded batches and grinding."""
import hashlib, json, signal, subprocess
from pathlib import Path
from run import ROOT, environment, write, bench_gate

OUT = Path(__file__).resolve().parent/'proof-equality'

def main():
    if OUT.exists():
        raise RuntimeError('proof-equality output already exists')
    OUT.mkdir()
    signal.signal(signal.SIGTERM, bench_gate.terminate)
    results = []
    bench_gate.acquire('falcon-binding-proof-equality', 5)
    try:
        for mode in ('arithmetic', 'full'):
            binary = ROOT/'target/witness-binding/bin'/('screen-v2-'+mode)
            for degree in (512, 1024):
                for security in (100, 128):
                    for batch in (1, 3):
                        expected = None
                        for stage, prefix in ([(0, 3), (7, 3), (7, 4)] if mode == 'arithmetic' else [(0, None), (7, None)]):
                            label = f'{mode}-n{degree}-s{security}-b{batch}-stage{stage}-k{prefix}'
                            env, explicit = environment(2, stage, 16)
                            if prefix:
                                env['BITZ_FALCON_BINDING_PREFIX'] = str(prefix)
                                explicit['BITZ_FALCON_BINDING_PREFIX'] = str(prefix)
                            command = ['taskset', '-c', '0,1', str(binary), '--degree', str(degree),
                                '--batch', str(batch), '--security', str(security), '--threads', '2',
                                '--warmup', '0', '--iterations', '1', '--seed', '42']
                            if mode == 'full':
                                command += ['--k', 'auto']
                            with (OUT/(label+'.jsonl')).open('w') as stdout, (OUT/(label+'.stderr')).open('w') as stderr:
                                proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                                try:
                                    assert proc.wait(timeout=300) == 0, label
                                except BaseException:
                                    bench_gate.stop_process_group(proc)
                                    raise
                            rows = [json.loads(line) for line in (OUT/(label+'.jsonl')).read_text().splitlines() if line.startswith('{')]
                            row, = [r for r in rows if r.get('trial') == 'sample']
                            assert row['verified']
                            identity = {key: row[key] for key in ('input_digest', 'proof_debug_digest', 'proof_payload_bytes')}
                            if expected is None:
                                expected = identity
                            assert identity == expected, label
                            results.append(dict(label=label, identity=identity, command=command, environment=explicit))
                            write(OUT/'results.json', results)
                            print(label, 'verified and matched', flush=True)
    finally:
        bench_gate.release()

if __name__ == '__main__':
    main()
