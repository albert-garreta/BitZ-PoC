#!/usr/bin/env python3
"""Freeze native production binaries and their complete local source manifest."""
import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def sources(root):
    paths = []
    for name in ('src', 'crates', 'vendor', 'benches', 'examples', '.cargo'):
        paths.extend(p for p in (root/name).rglob('*') if p.is_file() and 'target' not in p.relative_to(root).parts)
    paths.extend(p for p in root.iterdir() if p.is_file() and p.name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'build.rs'))
    return {str(p.relative_to(root)): sha(p) for p in sorted(set(paths))}

def main():
    kind = sys.argv[1]
    assert kind in ('baseline', 'candidate')
    source = ROOT/'target/witness-binding/baseline-src' if kind == 'baseline' else ROOT
    if kind == 'baseline':
        # Harness-only additions: untimed whole-proof digest and structured traces.
        # The complete baseline library remains the clean 91e577d41 archive.
        for name in ('examples/falcon_algebraic.rs', 'benches/falcon_hybrid.rs', 'benches/common/falcon_stage_timings.rs'):
            shutil.copy2(ROOT/name, source/name)
    manifest = dict(kind=kind, base_commit='91e577d4171bbec765dfe631ba7fa06abd487024',
        source=str(source), sources=sources(source),
        rustc=subprocess.check_output(['rustc', '-vV'], text=True),
        features=['falcon-hybrid'], default_features=True,
        rustflags='-C target-cpu=native', profile=dict(release=True, lto=True, codegen_units=1))
    manifest_path = OUT/(kind+'-build.json')
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
    env = dict(os.environ)
    for key in list(env):
        if key.startswith(('CARGO_PROFILE_', 'BITZ_', 'RAYON_', 'FLOCK_')) or key in ('FZF_DEFAULT_OPTS', 'CARGO_ENCODED_RUSTFLAGS'):
            env.pop(key)
    env.update(RUSTFLAGS=manifest['rustflags'], CARGO_TARGET_DIR=str(ROOT/'target/witness-binding'/('baseline-build' if kind == 'baseline' else 'build')), CARGO_BUILD_JOBS='2')
    command = ['cargo', 'build', '--offline', '--locked', '--release', '--features', 'falcon-hybrid',
        '--example', 'falcon_algebraic', '--bench', 'falcon_hybrid', '--message-format=json']
    manifest['command'] = command
    log = OUT/(kind+'-cargo.jsonl')
    with log.open('w') as stdout, (OUT/(kind+'-cargo.stderr')).open('w') as stderr:
        subprocess.run(command, cwd=source, env=env, stdout=stdout, stderr=stderr, check=True)
    assert manifest['sources'] == sources(source), 'source changed during compilation'
    manifest['binaries'] = {}
    for line in log.read_text().splitlines():
        record = json.loads(line)
        if record.get('reason') != 'compiler-artifact' or not record.get('executable'):
            continue
        mode = {'falcon_algebraic': 'arithmetic', 'falcon_hybrid': 'full'}.get(record['target']['name'])
        if mode:
            dest = ROOT/'target/witness-binding/bin'/(kind+'-'+mode)
            shutil.copy2(record['executable'], dest)
            manifest['binaries'][mode] = dict(path=str(dest), sha256=sha(dest), features=record['features'])
    assert set(manifest['binaries']) == {'arithmetic', 'full'}
    manifest['status'] = 'complete'
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')
    print(kind, 'build complete', flush=True)

if __name__ == '__main__':
    main()
