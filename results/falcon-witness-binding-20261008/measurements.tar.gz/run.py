#!/usr/bin/env python3
"""Matched Falcon binding experiments; all timings and failed runs are retained."""
import argparse, collections, hashlib, json, math, os, platform, signal, statistics, subprocess, sys, time, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import bench_gate


def write(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)

def digest(path):
    with open(path,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def environment(threads,stage=None,group=None,diagnostic=False,mode=None,disabled=0):
    env=dict(os.environ)
    for key in list(env):
        if key.startswith(('BITZ_','FLOCK_','RAYON_','LIG_','LIGERITO_','PCS_','CARGO_PROFILE_')) or key in ('RUST_LOG','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','PERFETTO_TRACE','FZF_DEFAULT_OPTS'):
            env.pop(key,None)
    explicit=dict(RAYON_NUM_THREADS=str(threads),BITZ_FALCON_WORKER_CPUS=','.join(map(str,range(threads))),
        BITZ_FALCON_MAIN_CPU='0',BITZ_FALCON_CASE_CACHE='/tmp/falcon-algebraic-cases-20261007',
        FLOCK_NO_PREFAULT='1',RUSTFLAGS='-C target-cpu=native')
    if stage is not None:explicit['BITZ_FALCON_BINDING_STAGE']=str(stage)
    if group is not None:explicit['BITZ_FALCON_BINDING_GROUP']=str(group)
    if disabled:explicit['BITZ_FALCON_BINDING_DISABLE']=str(disabled)
    if diagnostic and mode=='full':explicit['BITZ_FALCON_STAGE_TIMINGS']='1'
    env.update(explicit);return env,explicit


def stats(values):
    return dict(median=statistics.median(values),minimum=min(values),maximum=max(values),samples=values)


def compare(pairs,metric,limit=1.01):
    ratios=[math.log(b['metrics'][metric]['median']/a['metrics'][metric]['median']) for a,b in pairs]
    mean=statistics.mean(ratios)
    if len(ratios)<2:return dict(status='inconclusive',ratio=math.exp(mean))
    critical={2:12.706,3:4.303,4:3.182,5:2.776,6:2.571,7:2.447,8:2.365,9:2.306,10:2.262}[len(ratios)]
    radius=critical*statistics.stdev(ratios)/math.sqrt(len(ratios));lo,hi=math.exp(mean-radius),math.exp(mean+radius)
    return dict(ratio=math.exp(mean),ci95=[lo,hi],status='pass' if (hi<limit if limit==1.0 else hi<=limit) else 'regression' if lo>limit else 'inconclusive',
        baseline_ms=statistics.median([a['metrics'][metric]['median'] for a,b in pairs]),
        candidate_ms=statistics.median([b['metrics'][metric]['median'] for a,b in pairs]),paired_log_ratios=ratios)


def parse_stages(path,mode):
    root='falcon_bench:prove' if mode=='full' else 'falcon_algebraic:prove'
    binding_name='falcon_arithmetic:binding_inner' if mode=='full' else 'falcon_algebraic:binding'
    pending=collections.defaultdict(float);binding_pending=collections.defaultdict(float);trials=[];binding_trials=[]
    for line in path.read_text().splitlines():
        if not line.startswith('{'):continue
        event=json.loads(line)
        if event.get('event')!='stage' or root not in event.get('path',[]):continue
        pending[event['name']]+=event['elapsed_ms']
        if binding_name in event['path']:
            binding_pending[event['name']]+=event['elapsed_ms']
        if event['name']==root:
            trials.append(dict(pending));pending.clear()
            binding_trials.append(dict(binding_pending));binding_pending.clear()
    assert len(trials)==6 and not pending,(len(trials),pending)
    stages={name:stats([trial.get(name,0) for trial in trials[1:]]) for name in set().union(*trials)}
    binding_stages={name:stats([trial.get(name,0) for trial in binding_trials[1:]]) for name in set().union(*binding_trials)}
    return stages,stages[binding_name],binding_stages


def run_one(out,name,binary,mode,degree,threads,stage,group,diagnostic,disabled,identities):
    env,explicit=environment(threads,stage,group,diagnostic,mode,disabled)
    binary_hash=digest(binary)
    assert identities.setdefault("binary:"+str(binary),binary_hash)==binary_hash, "executable changed during campaign"
    command=['taskset','-c',explicit['BITZ_FALCON_WORKER_CPUS'],str(binary),'--degree',str(degree),'--batch','1024',
        '--security','100','--threads',str(threads),'--warmup','1','--iterations','5','--seed','42']
    if mode=='full':command+=['--k','auto']
    elif diagnostic:command+=['--trace']
    stdout=out/(name+'.jsonl');stderr=out/(name+'.stderr')
    entry=dict(name=name,binary=str(binary),binary_sha256=binary_hash,command=command,environment=explicit,
        mode=mode,degree=degree,threads=threads,stage=stage,group=group,disabled=disabled,status='running')
    write(out/(name+'.run.json'),entry)
    start=time.monotonic();swap=bench_gate.swap_used_gb()
    with stdout.open('w') as a,stderr.open('w') as b:
        proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=a,stderr=b,start_new_session=True)
        try:
            while proc.poll() is None:
                if time.monotonic()-start>1800 or bench_gate.swap_used_gb()-swap>2:
                    raise RuntimeError('timeout or swap growth')
                time.sleep(1)
        except BaseException:
            bench_gate.stop_process_group(proc);raise
    entry.update(returncode=proc.returncode,elapsed_seconds=time.monotonic()-start)
    if proc.returncode!=0:
        entry['status']='failed';write(out/(name+'.run.json'),entry);raise RuntimeError(f'{name} exited {proc.returncode}')
    records=[json.loads(x) for x in stdout.read_text().splitlines() if x.startswith('{')]
    rows=[r for r in records if r.get('trial') in ('warmup','sample')]
    assert [r['trial'] for r in rows]==['warmup']+['sample']*5
    header=records[0] if mode=='full' else rows[0]
    assert header['algebraic_security_bits']>=100
    assert header['build_rustflags']=='-C target-cpu=native'
    affinity=header['cpu_affinity']
    assert affinity['observed_worker_cpus']==[[i] for i in range(threads)]
    assert affinity['observed_main_cpus']==[0]
    for row in rows:
        assert row['verified'] and row['degree']==degree and row['batch']==1024 and row['threads']==threads
        assert row.get('security_target',row.get('security_bits'))==100
        identity={key:row[key] for key in ('input_digest','proof_debug_digest','proof_payload_bytes')}
        assert identities.setdefault(f'input:{degree}',row['input_digest'])==row['input_digest'], 'cross-mode corpus mismatch'
        key=f'{mode}-{degree}'
        assert identities.setdefault(key,identity)==identity,(key,identity,identities[key])
    mapping=dict(prove_ms='proof_prove_ms' if mode=='full' else 'prove_ms',total_prover_ms='total_prover_ms',
        witness_commit_ms='witness_commit_ms',verify_ms='proof_verify_ms' if mode=='full' else 'verify_ms')
    metrics={name:stats([r[key] for r in rows[1:]]) for name,key in mapping.items()}
    if diagnostic:
        stages,binding,binding_stages=parse_stages(stderr,mode);entry['stages']=stages;entry['binding_stages']=binding_stages;metrics['binding_ms']=binding
    entry.update(status='complete',metrics=metrics,identity=identity,verified_trials=len(rows),
        process_peak_rss_kib=max(r.get('process_peak_rss_kib') or 0 for r in rows))
    write(out/(name+'.run.json'),entry)
    print(f'{name}: prove={metrics["prove_ms"]["median"]:.3f} ms total={metrics["total_prover_ms"]["median"]:.3f} ms',flush=True)
    return entry


def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['screen','qualify','diagnostic'],required=True)
    p.add_argument('--bin-dir',type=Path,default=ROOT/'target/witness-binding/bin');p.add_argument('--out',type=Path)
    p.add_argument('--cycles',type=int);p.add_argument('--disable',type=int,default=0);p.add_argument('--group',type=int,choices=[1,8,16],default=8)
    p.add_argument('--trace-screen',action='store_true',help='Separate instrumented screening pass')
    p.add_argument('--selected-groups',action='store_true',help='Use measured caps16/8 for full degrees512/1024 outside the cap comparison')
    p.add_argument('--caps',default='8,16',help='Grouping caps to screen at step4; comma-separated1,8,16')
    p.add_argument('--case',help='Optional mode:degree:threads filter');p.add_argument('--steps',help='Comma-separated target screening stages')
    args=p.parse_args();out=args.out or Path(__file__).resolve().parent/('screen-trace' if args.trace_screen else args.phase)
    if out.exists() and any(out.iterdir()):raise RuntimeError(f'refusing to overwrite {out}')
    out.mkdir(parents=True,exist_ok=True)
    shutil.copy2(__file__,out/'runner.py.snapshot')
    signal.signal(signal.SIGTERM,bench_gate.terminate)
    cycles=args.cycles or (1 if args.phase=='screen' else 3); assert 1<=cycles<=5
    assert args.phase=='screen' or (not args.trace_screen and not args.selected_groups and args.disable==0 and args.group==8), 'screen controls require --phase screen'
    caps=list(map(int,args.caps.split(',')));assert caps and all(c in (1,8,16) for c in caps)
    cells=[]
    if args.phase=='screen':
        allowed=set(map(int,args.steps.split(','))) if args.steps else set(range(1,8))
        for step in range(1,8):
            if step not in allowed:continue
            modes=['arithmetic','full'] if step==1 else ['arithmetic'] if step==2 else ['full']
            for mode in modes:
                for degree in (512,1024):
                    cap=(16 if degree==512 else 8) if args.selected_groups and mode=='full' else args.group
                    for group in (caps if step==4 else [cap]):
                        cells.append(dict(mode=mode,degree=degree,threads=8,label=f'step{step}-g{group}',
                            variants=[('a','screen',step-1,cap,args.disable),('b','screen',step,group,args.disable)]))
    else:
        for mode in ('arithmetic','full'):
            for degree in (512,1024):
                for threads in ([8] if args.phase=='diagnostic' else [1,2,4,8,16]):
                    cells.append(dict(mode=mode,degree=degree,threads=threads,label=args.phase,
                        variants=[('a','baseline',None,None,0),('b','candidate',None,None,0)]))
    if args.case:
        mode,degree,threads=args.case.split(':');cells=[c for c in cells if (c['mode'],c['degree'],c['threads'])==(mode,int(degree),int(threads))]
    assert cells
    manifest=dict(baseline_commit='91e577d4171bbec765dfe631ba7fa06abd487024',platform=platform.platform(),
        phase=args.phase,cycles=cycles,runner_sha256=digest(__file__),batch=1024,security=100,
        cells=cells,runs=[],comparisons=[],initial_idle_seconds=120,cell_idle_seconds=15,status='waiting',started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
    identities={}
    if args.phase!='screen':
        builds={kind:json.loads((Path(__file__).resolve().parent/(kind+'-build.json')).read_text()) for kind in ('baseline','candidate')}
        for key in ('base_commit','rustc','features','default_features','rustflags','profile'):
            assert builds['baseline'][key]==builds['candidate'][key], ('build mismatch',key)
        for kind,build in builds.items():
            assert build['status']=='complete' and build['features']==['falcon-hybrid']
            for mode,item in build['binaries'].items():
                binary=args.bin_dir/(kind+'-'+mode)
                assert item['sha256']==digest(binary)
                assert 'bench-internals' not in item['features']
                identities['binary:'+str(binary)]=item['sha256']
        for mode in ('arithmetic','full'):
            assert builds['baseline']['binaries'][mode]['features']==builds['candidate']['binaries'][mode]['features']
        manifest['builds']={kind:dict(path=str(Path(__file__).resolve().parent/(kind+'-build.json')),sha256=digest(Path(__file__).resolve().parent/(kind+'-build.json'))) for kind in builds}
    write(out/'manifest.json',manifest)
    bench_gate.acquire('falcon-witness-binding-'+args.phase,5)
    try:
        bench_gate.wait_idle('campaign-start',88,120,5,600)
        for cell in cells:
            mode,degree,threads=cell['mode'],cell['degree'],cell['threads']
            label=f'{cell["label"]}-{mode}-n{degree}-t{threads}'
            bench_gate.wait_idle(label,88,15,5,300)
            pairs=[]
            for pair in range(2*cycles):
                results={}
                for index in ([0,1] if pair%2==0 else [1,0]):
                    side,variant,stage,group,disabled=cell['variants'][index]
                    binary=args.bin_dir/(variant+'-'+mode)
                    result=run_one(out,f'{label}-pair{pair}-{side}',binary,mode,degree,threads,stage,group,
                        args.phase=='diagnostic' or args.trace_screen,disabled,identities)
                    manifest['runs'].append(result);results[side]=result;write(out/'manifest.json',manifest)
                pairs.append((results['a'],results['b']))
            comparison={**cell,'metrics':{key:compare(pairs,key,1.0 if key=='binding_ms' else 1.01) for key in pairs[0][0]['metrics']}}
            manifest['comparisons'].append(comparison);write(out/'summary.json',manifest['comparisons']);write(out/'manifest.json',manifest)
        manifest['status']='complete'
    except BaseException as e:
        manifest.update(status='failed',error=repr(e));raise
    finally:
        write(out/'manifest.json',manifest);bench_gate.release()

if __name__=='__main__':main()
