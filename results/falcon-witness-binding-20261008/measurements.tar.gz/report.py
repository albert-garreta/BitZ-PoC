#!/usr/bin/env python3
"""Generate the before/after tables directly from retained campaign results."""
import html, json, re, statistics
from pathlib import Path
from run import parse_stages

ROOT = Path(__file__).resolve().parent

def read(name):
    return json.loads((ROOT/name).read_text())

def esc(value):
    return html.escape(str(value))

def metric(value):
    lo, hi = value['ci95']
    return (f"{value['baseline_ms']:.3f} → {value['candidate_ms']:.3f} ms"
            f"<br><small>ratio {value['ratio']:.4f}; 95% CI [{lo:.4f}, {hi:.4f}]</small>")

def key(cell):
    return cell['mode'], cell['degree'], cell['threads']

def table(headings, rows):
    return '<table><thead><tr>'+''.join('<th>'+esc(h)+'</th>' for h in headings)+'</tr></thead><tbody>'+''.join(
        '<tr>'+''.join('<td>'+str(v)+'</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table>'

def tests(name):
    text = (ROOT/name).read_text()
    matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    assert matches, name
    return dict(zip(('passed', 'failed', 'ignored'), map(int, matches[-1])))

def main():
    qualification = read('qualify/manifest.json')
    diagnostic = read('diagnostic/manifest.json')
    assert qualification['status'] == diagnostic['status'] == 'complete'
    assert len(qualification['comparisons']) == 20 and len(diagnostic['comparisons']) == 4
    qualified = all(c['metrics'][k]['status']=='pass' for c in qualification['comparisons']
        for k in ('prove_ms','total_prover_ms')) and all(
        c['metrics']['binding_ms']['status']=='pass' for c in diagnostic['comparisons'])
    assert qualified, 'Final gates did not all pass; revise production selection before publishing a retained-choices report.'
    diag = {key(c): c for c in diagnostic['comparisons']}
    decisions = read('decisions.json')
    checks = {name: tests(path) for name, path in (
        ('packed', 'tests-final-packed.log'), ('Falcon', 'tests-final-falcon.log'),
        ('production integration', 'tests-production-integration.log'))}
    assert all(c['failed'] == 0 for c in checks.values())
    assert 'Finished `dev` profile' in (ROOT/'check-serial.log').read_text()
    equality = read('proof-equality/results.json')
    equality_comparisons = sum('-stage0-' not in r['label'] for r in equality)
    campaigns = []
    for p in sorted(ROOT.glob('*/manifest.json')):
        m = json.loads(p.read_text())
        if 'comparisons' in m:
            campaigns.append(dict(path=str(p.relative_to(ROOT)), status=m['status'],
                verified_proofs=sum(r.get('verified_trials', 0) for r in m['runs'])))
    analysis = dict(baseline=qualification['baseline_commit'], qualified=qualified, decisions=decisions, tests=checks,
        untimed_proofs=len(equality), untimed_equality_comparisons=equality_comparisons, qualification=qualification['comparisons'],
        diagnostic=diagnostic['comparisons'], campaigns=campaigns)
    (ROOT/'analysis.json').write_text(json.dumps(analysis, indent=2)+'\n')

    primary, matrix = [], []
    for cell in qualification['comparisons']:
        name=f"{cell['mode'].title()} Falcon-{cell['degree']}"
        m=cell['metrics']
        verdict='pass' if all(m[k]['status']=='pass' for k in ('prove_ms','total_prover_ms')) else '/'.join(m[k]['status'] for k in ('prove_ms','total_prover_ms'))
        matrix.append([esc(name), cell['threads'], metric(m['prove_ms']), metric(m['total_prover_ms']), esc(verdict)])
        if cell['threads']==8:
            binding=diag[key(cell)]['metrics']['binding_ms']
            primary.append([esc(name), metric(binding), f"{100*(1-binding['ratio']):.1f}%",
                metric(m['prove_ms']), metric(m['total_prover_ms'])])

    components=[]
    full_details=[]
    for mode in ('arithmetic','full'):
        for degree in (512,1024):
            process={side:[] for side in ('a','b')}
            for run in diagnostic['runs']:
                if (run['mode'],run['degree']) != (mode,degree): continue
                _, _, scoped=parse_stages(ROOT/'diagnostic'/(run['name']+'.stderr'),mode)
                process[run['name'][-1]].append(scoped)
            prefix='inner_packed:' if mode=='arithmetic' else 'inner_overlay:'
            values=[]
            for component in ('prefix_accumulators','prepare_tail','fold_tail'):
                before,after=[statistics.median(p[prefix+component]['median'] for p in process[side]) for side in ('a','b')]
                values.append(f'{before:.3f} → {after:.3f} ms')
            components.append([f'{mode.title()} Falcon-{degree}',*values])
            if mode=='full':
                names=('integer_prefix','ring_prefix','folded_coefficients','first_tail_round')
                full_details.append([f'Full Falcon-{degree}',*(
                    f"{statistics.median(p['inner_overlay:'+name]['median'] for p in process['b']):.3f} ms"
                    for name in names)])

    experiments=[]
    for campaign in campaigns:
        if not campaign['path'].startswith('screen'): continue
        m=read(campaign['path'])
        for cell in m['comparisons']:
            b=cell['metrics'].get('binding_ms')
            experiments.append([esc(Path(campaign['path']).parent.name),esc(cell['label']),
                f"{cell['mode']} {cell['degree']}", metric(b) if b else 'Uninstrumented',
                metric(cell['metrics']['prove_ms']), esc(b['status'] if b else cell['metrics']['prove_ms']['status'])])
    content='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Falcon witness binding qualification</title><style>
body{font:16px/1.5 system-ui,sans-serif;max-width:1250px;margin:40px auto;padding:0 22px;color:#18232d;background:#fafbfd}
h1,h2{line-height:1.2}table{border-collapse:collapse;width:100%;margin:20px 0;background:white}th,td{padding:12px;border-bottom:1px solid #dde3e9;text-align:left;vertical-align:top}th{background:#edf2f6}small{color:#526272}a{color:#1657a3}summary{cursor:pointer;font-weight:650}code{background:#edf2f6;padding:2px 4px}pre{white-space:pre-wrap} .scroll{overflow:auto}
</style><h1>Falcon witness binding qualification</h1>'''
    content+='<p>Baseline <code>91e577d41</code>. Linux, AMD Ryzen 9 9950X3D; 1,024 signatures and 100-bit security. Packing, PCS algorithms, security scheduling, and the merged norm protocol are unchanged.</p>'
    content+='<h2>Eight-thread result</h2>'+table(['Workload','Binding','Binding reduction','Proof generation','Total prover'],primary)
    content+='<p>Production latency uses tracing-disabled binaries built with identical native release settings and <code>falcon-hybrid</code>. Binding times come from separate matched diagnostic processes. Each comparison uses three ABBA cycles: six paired process medians, one warmup and five measured proofs per process, 30 measured proofs per variant.</p>'
    content+='<p>Ratios are geometric means of paired process-median ratios, with two-sided 95% Student-t intervals on log ratios. Proof-generation and total-prover time pass when the upper bound is ≤1.01; binding improvement requires an upper bound &lt;1. Nested diagnostic spans are not added to parent totals.</p>'
    content+='<h2>Retained choices</h2><ul>'+''.join('<li>'+esc(choice)+'.</li>' for choice in decisions['retained'])+'</ul>'
    content+='<p>Full-Falcon grouping caps: 16 for Falcon-512 and 8 for Falcon-1024. Arithmetic keeps K3. Tail fusion remains disabled: both measured implementations failed acceptance. The original slow replay pair is retained in the <a href="replay-confirmation-analysis.json">confirmation analysis</a>.</p>'
    content+='<p>'+esc(decisions['production_scope'])+' <a href="decisions.json">Complete selection evidence</a>.</p>'
    content+='<h2>Binding components at eight threads</h2>'+table(['Workload','Prefix accumulation','Tail preparation','Subsequent folding'],components)
    content+='<p>Candidate full-Falcon detail (nested within the prefix and preparation spans above):</p>'+table(['Workload','Integer prefix','Ring prefix','Coefficient table','First tail message'],full_details)
    content+='<h2>Thread regression matrix</h2><div class="scroll">'+table(['Workload','Threads','Proof generation','Total prover','Gate'],matrix)+'</div>'
    content+='<h2>Correctness</h2><ul>'+''.join(f'<li>{esc(name)}: {r["passed"]} passed, {r["failed"]} failed, {r["ignored"]} ignored.</li>' for name,r in checks.items())+f'<li>{len(equality)} untimed proofs verified; {equality_comparisons} candidate/reference complete-proof digest comparisons matched, including K3/K4, singleton/padded batches, and 100/128-bit grinding schedules.</li><li>The supported non-parallel compile check passed.</li></ul>'
    content+='<details><summary>Independent experiments, including rejected candidates</summary><div class="scroll">'+table(['Campaign','Change','Workload','Binding','Proof generation','Gate'],experiments)+'</div></details>'
    content+='<h2>Raw evidence</h2><ul>'+''.join(f'<li><a href="{esc(c["path"])}">{esc(c["path"])}</a>: {c["status"]}, {c["verified_proofs"]} verified proofs.</li>' for c in campaigns)+'</ul>'
    content+='<p>All raw samples, structured traces, process records, and build output are retained in <a href="raw-runs.tar.gz">raw-runs.tar.gz</a>, with a <a href="raw-runs.json">SHA-256 manifest</a>. Extract the archive in this report directory before rerunning the analysis scripts.</p>'
    content+='<p><a href="baseline-build.json">Baseline build provenance</a> · <a href="candidate-build.json">Candidate build provenance</a> · <a href="proof-equality/results.json">Untimed equality results</a> · <a href="validation-assembly.txt">Validation assembly</a> · <a href="analysis.json">Machine-readable report</a> · <a href="run.py">Benchmark runner</a></p></html>'
    (ROOT/'report.html').write_text(content)
    print(ROOT/'report.html')

if __name__=='__main__': main()
