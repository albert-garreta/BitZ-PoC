//! Prover-only Falcon binding choices. Benchmark overrides never affect the
//! transcript and are absent from ordinary production builds.
//!
//! Stages: 0 reference, 1 direct validation, 2 arithmetic constants,
//! 3 bounded products, 4 grouped prefixes, 5 output-oriented replay,
//! 6 ring byte pairs, 7 fused tail. Each stage includes its predecessors.

#[derive(Clone, Copy, Debug)]
pub(crate) struct BindingTuning {
    pub stage: u8,
    pub group_cap: usize,
    pub disabled: u8,
}

impl BindingTuning {
    pub const REFERENCE: Self = Self {
        stage: 0,
        group_cap: 1,
        disabled: 0,
    };

    pub fn enabled(self, step: u8) -> bool {
        self.stage >= step && self.disabled & (1 << (step - 1)) == 0
    }

    pub fn for_arithmetic(batch: usize, degree: usize, ungrinded_binding: bool) -> Self {
        // Of the supported 100/128-bit schedules, only 100 bits has no binding grind.
        Self::for_workload(batch, degree, false, ungrinded_binding)
    }

    pub fn for_full(batch: usize, degree: usize, security_bits: usize, extension: usize) -> Self {
        Self::for_workload(batch, degree, true, security_bits == 100 && extension == 9)
    }

    fn for_workload(batch: usize, degree: usize, full: bool, security_100: bool) -> Self {
        #[cfg(feature = "parallel")]
        let workers = rayon::current_num_threads();
        #[cfg(not(feature = "parallel"))]
        let workers = 1;
        let qualified = cfg!(all(target_os = "linux", target_arch = "x86_64"))
            && batch == 1024
            && matches!(degree, 512 | 1024)
            && security_100
            && matches!(workers, 1 | 2 | 4 | 8 | 16);
        let mut result = if qualified || cfg!(test) {
            Self {
                stage: if full { 6 } else { 2 },
                group_cap: if full && degree == 512 { 16 } else { 8 },
                disabled: 0,
            }
        } else {
            Self::REFERENCE
        };
        #[cfg(feature = "bench-internals")]
        {
            if let Ok(value) = std::env::var("BITZ_FALCON_BINDING_STAGE") {
                result.stage = value
                    .parse()
                    .expect("binding stage must be an integer 0..=7");
                assert!(result.stage <= 7, "binding stage must be in 0..=7");
            }
            if let Ok(value) = std::env::var("BITZ_FALCON_BINDING_DISABLE") {
                result.disabled = value
                    .parse()
                    .expect("binding disable must be a bit mask 0..=127");
                assert!(result.disabled <= 127);
            }
            if let Ok(value) = std::env::var("BITZ_FALCON_BINDING_GROUP") {
                result.group_cap = value.parse().expect("binding group must be 1, 8, or 16");
                assert!(matches!(result.group_cap, 1 | 8 | 16));
            }
        }
        #[cfg(not(feature = "bench-internals"))]
        let _ = &mut result;
        result
    }
}

impl Default for BindingTuning {
    fn default() -> Self {
        if cfg!(test) {
            Self {
                stage: 7,
                group_cap: 8,
                disabled: 0,
            }
        } else {
            Self::REFERENCE
        }
    }
}
