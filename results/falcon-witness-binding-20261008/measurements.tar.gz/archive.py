#!/usr/bin/env python3
"""Bundle raw logs omitted from Git; extract in this directory to replay analysis."""
import hashlib, json, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    paths = sorted(p for p in ROOT.rglob('*') if p.is_file() and (
        p.suffix in ('.jsonl', '.stderr') or p.name.endswith(('.run.json', '-progress.log'))))
    archive = ROOT/'raw-runs.tar.gz'
    manifest = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    with tarfile.open(archive, 'w:gz', compresslevel=6) as output:
        for p in paths:
            output.add(p, arcname=str(p.relative_to(ROOT)), recursive=False)
    with archive.open('rb') as stream:
        sha = hashlib.file_digest(stream, 'sha256').hexdigest()
    (ROOT/'raw-runs.json').write_text(json.dumps(dict(archive=archive.name, sha256=sha,
        extraction='tar -xzf raw-runs.tar.gz', files=manifest), indent=2)+'\n')
    print(f'{len(paths)} raw files; {archive.stat().st_size/2**20:.1f} MiB compressed')


if __name__ == '__main__': main()
