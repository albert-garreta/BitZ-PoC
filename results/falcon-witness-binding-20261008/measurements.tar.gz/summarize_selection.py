#!/usr/bin/env python3
"""Record selection from all screening evidence, including the slow replay pair."""
import json, math, statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def campaign(name):
    result = json.loads((ROOT/name/'manifest.json').read_text())
    assert result['status'] == 'complete', name
    return result


def main():
    latency = campaign('screen-production-v2')
    trace = campaign('screen-trace')
    cap1 = campaign('screen-cap1-v2')
    confirmation = campaign('screen-replay-confirmation')
    fusion = campaign('screen-fusion-v2')
    original = next(c for c in latency['comparisons'] if c['label']=='step5-g8' and c['degree']==1024)
    repeated = confirmation['comparisons'][0]
    assert all(repeated['metrics'][k]['status']=='pass' for k in ('prove_ms','total_prover_ms'))
    pooled = {}
    for metric in ('prove_ms', 'total_prover_ms'):
        logs = original['metrics'][metric]['paired_log_ratios'] + repeated['metrics'][metric]['paired_log_ratios']
        assert len(logs) == 12
        mean = statistics.mean(logs)
        # Student-t, 11 degrees of freedom, two-sided 95% interval.
        radius = 2.200985 * statistics.stdev(logs)/math.sqrt(len(logs))
        lo, hi = math.exp(mean-radius), math.exp(mean+radius)
        pooled[metric] = dict(ratio=math.exp(mean), ci95=[lo, hi], paired_log_ratios=logs,
            status='pass' if hi<=1.01 else 'regression' if lo>1.01 else 'inconclusive')
    replay = dict(reason='Both variants slowed abruptly in the final original pair. One fixed-size confirmation was added; no samples were discarded.',
        interpretation='The pooled interval is nominal/descriptive because the confirmation was triggered by observed noise. The confirmation independently passes; final acceptance also requires the separate fixed-size production qualification.',
        original=original, confirmation=repeated, pooled_all_twelve_pairs=pooled)
    (ROOT/'replay-confirmation-analysis.json').write_text(json.dumps(replay, indent=2)+'\n')

    gates = []
    for cell in latency['comparisons']:
        if cell['label'].startswith('step7'): continue
        metrics = pooled if cell is original else cell['metrics']
        gate = dict(change=cell['label'], mode=cell['mode'], degree=cell['degree'],
            metrics={k:metrics[k] for k in ('prove_ms','total_prover_ms')})
        gates.append(gate)
        assert all(v['status']=='pass' for v in gate['metrics'].values()), gate
    for cell in trace['comparisons']:
        if not cell['label'].startswith('step7'):
            assert cell['metrics']['binding_ms']['status']=='pass', cell
    groups = {}
    for degree in (512,1024):
        values = {int(c['label'].split('-g')[1]):c['metrics']['binding_ms']['candidate_ms']
            for c in trace['comparisons'] if c['label'].startswith('step4') and c['degree']==degree}
        fastest = min(values.values())
        selected = min(cap for cap, value in values.items() if value<=1.01*fastest)
        groups[degree] = dict(cap=selected, binding_medians_ms=values,
            cap1_control=next(c for c in cap1['comparisons'] if c['degree']==degree),
            rule='Smallest passing cap within 1% of the fastest binding median; cap 1 retains the ungrouped path.')
    assert groups[512]['cap']==16 and groups[1024]['cap']==8
    decisions = dict(retained=[
        'Direct Montgomery-residue canonical validation',
        'Prepared arithmetic decoder, weighted padding, and doubled slack',
        'Bounded product reduction for full-Falcon folded coefficients',
        'Grouped full-Falcon integer-prefix difference tables',
        'Coefficient-oriented full-Falcon replay',
        'Full-Falcon ring-column K4 byte-pair adapter'],
        disabled=['Full-Falcon fused first-tail accumulation remains available only through test/benchmark controls.'],
        fusion_evidence=dict(original='screen-trace/manifest.json', revised_latency=[c for c in latency['comparisons'] if c['label'].startswith('step7')], revised_binding=fusion['comparisons']),
        groups=groups, arithmetic_prefix='K3 unchanged',
        production_scope='Linux x86_64; batch 1024; Falcon-512/1024; 100-bit security; threads 1/2/4/8/16; full Falcon extension K9. Reference behavior elsewhere.',
        unchanged=['Witness packing and committed witness', 'PCS algorithms and proof format', 'Security schedule and merged norm protocol', 'Existing arithmetic construction/evaluation selection'],
        latency_gates=gates, replay_confirmation='replay-confirmation-analysis.json',
        qualification='Final production qualification and diagnostic campaigns are reported separately in analysis.json.')
    (ROOT/'decisions.json').write_text(json.dumps(decisions, indent=2)+'\n')
    print('Screening selection passed; stages 2/6, full-Falcon caps 16/8.')


if __name__ == '__main__': main()
