# Regression repair campaign

The original measurements remain in `results/optimization-arm-01` and
`results/optimization-arm-10cores-01`. This revision changes only the isolated
experiment. ARM and portable implementations are in scope; production and x86
code are unchanged.

## Changes under measurement

- Compile integer operation/signedness into batch kernels. Use native one- and
  two-word arithmetic, or the existing crypto-bigint carry primitive where it
  generates better code. Preserve the full `Option<Uint>` checked result.
- Accumulate exact unsigned products in wide columns, propagate carries once,
  and validate the public batch-capacity bound once. The output still has
  `2L+1` words. BigUint validates the result, including short batches and tails.
- Write packing output through spare capacity, initialize every value/padding
  slot once, and use coarse parallel work for large buffers. Retain the returned
  packed buffer through OOD evaluation.
- Compare equality-table and OOD block schedules while retaining the actual
  extracted production implementation as the baseline.
- Reuse the tested ARM half-width multiplier inside NTT butterflies. Compare
  depth-first and tiled schedules with equal reset copies and complete outputs.
- Keep explicitly public-input polynomial arithmetic separate from the
  fixed-schedule private-input kernel. The revised public path checks each
  row's actual contents, skips zero rows, compacts sparse operands, and fuses
  products directly into the accumulator.
  Correctness and performance cases include all-zero inputs, alternating rows,
  and prefixes that misrepresent later terms. The earlier prefix-sampling
  candidate remains a diagnostic. Sampling is never added to the fixed-schedule
  entry point.

## Allocation audit correction

A temporary allocation backtrace identified the intermittent 1,520-byte event
as `crossbeam_deque::Injector::push` allocating a Rayon job-queue block. The
captured event occurred in the **production NTT baseline**, too. The trace is
preserved in `results/repair-dev-10cores-03/run-0.log`; that instrumented build
is development evidence only.

The prior three-pass maximum could happen to cross a queue-block boundary in
one variant and miss it in another. The audit now uses **64 passes**, covering
at least two periods of the 31-job injector block. It still reports the maximum
allocation count/bytes for **one call**, includes scheduler allocations, and
retains the original comparison limits. The tiled candidate also enters the
worker pool once for a complete transform, reducing external job submissions.
Timing measurements remain separate from allocation auditing.

## Confirmation policy

Development probes are labeled as such and preserve their raw pairs. They are
used to choose implementations before fresh confirmation, never presented as
passing the final gate. Confirmation keeps five fresh processes, 32 paired
samples, the 1% latency limit, P95/per-process checks, and at most one prescribed
64-sample retry for an inconclusive workload. Rejected variants remain visible.

`results/repair-arm-01` was stopped before completion to add the missing mixed
and misleading-prefix performance cases. Its metadata says `aborted`; its
partial timings were not used to select candidates or claim confirmation.

Where a specialization has no dependable advantage, retaining the actual
baseline is an explicit implementation choice, not a speedup. Private-input
timing guarantees cannot be exchanged for the public-input sparse path.
