use crate::{Case, Rng, arithmetic, case_requested, measure};
use f2z::{poly::univariate::binary_gf128::BinaryFieldGF128 as Gf, utils::wide_mul::WideMulAcc};
use flock_core::{field::F128, ntt::AdditiveNttF128};
use rayon::prelude::*;
use std::hint::black_box;

// Write each equality weight once per coordinate, reuse its product for both
// children, and allocate the final table once. Index bit k belongs to point[k].
fn eq_into(point: &[Gf], out: &mut [Gf]) {
    assert_eq!(out.len(), 1usize << point.len());
    out[0] = Gf::one();
    let mut n = 1;
    for &z in point {
        let (lo, hi) = out[..2 * n].split_at_mut(n);
        for (a, b) in lo.iter_mut().zip(hi) {
            *b = *a * z;
            *a += *b;
        }
        n *= 2;
    }
}
fn eq(point: &[Gf]) -> Vec<Gf> {
    let mut out = vec![Gf::zero(); 1 << point.len()];
    eq_into(point, &mut out);
    out
}

#[inline(never)]
fn ood_reuse(p: &[F128], point: &[Gf], tail: &mut [Gf], head: &mut [Gf]) -> Gf {
    assert_eq!(p.len(), 1usize << point.len());
    let lo = point.len().min(12);
    let block = 1 << lo;
    assert_eq!(tail.len(), block);
    assert_eq!(head.len(), p.len() / block);
    eq_into(&point[..lo], tail);
    eq_into(&point[lo..], head);
    // Parallel reduction removes the intermediate inner Vec. Reduction ordering
    // is exact over the binary field. Scratch covers only public shape.
    let wide = p
        .par_chunks_exact(block)
        .zip(head.par_iter())
        .map(|(p, &h)| {
            let mut acc = Gf::wide_zero(&Gf::zero());
            for (&m, t) in p.iter().zip(tail.iter()) {
                Gf::wide_add_assign(&mut acc, &Gf::mul_wide(&Gf::from_words([m.lo, m.hi]), t));
            }
            Gf::mul_wide(&Gf::from_wide(acc), &h)
        })
        .reduce(
            || Gf::wide_zero(&Gf::zero()),
            |mut a, b| {
                Gf::wide_add_assign(&mut a, &b);
                a
            },
        );
    Gf::from_wide(wide)
}
fn ood(p: &[F128], point: &[Gf]) -> Gf {
    let lo = point.len().min(12);
    let mut tail = vec![Gf::zero(); 1 << lo];
    let mut head = vec![Gf::zero(); 1 << (point.len() - lo)];
    ood_reuse(p, point, &mut tail, &mut head)
}
fn ood_cases(samples: usize, rng: &mut Rng) {
    for log in [0, 1, 3, 10, 16, 18] {
        let size = format!("log{log}");
        if log >= 10
            && !["opt_ood", "opt_ood_reuse"]
                .iter()
                .any(|f| case_requested(f, &size))
        {
            continue;
        }
        let p = rng.values(1 << log);
        let point: Vec<_> = rng
            .values(log)
            .iter()
            .map(|v| Gf::from_words([v.lo, v.hi]))
            .collect();
        let expected = crate::production_ood::evaluate(&p, &point);
        assert_eq!(ood(&p, &point), expected);
        let weights = eq(&point);
        let oracle = p.iter().zip(&weights).fold(Gf::zero(), |acc, (p, w)| {
            acc + Gf::from_words([p.lo, p.hi]) * *w
        });
        assert_eq!(oracle, expected);
        if log < 10 {
            continue;
        }
        let mut cases = vec![
            Case::new("production_blocked", p.len() * 16, || {
                black_box(crate::production_ood::evaluate(
                    black_box(&p),
                    black_box(&point),
                ));
            }),
            Case::new("reuse_products", p.len() * 16, || {
                black_box(ood(black_box(&p), black_box(&point)));
            }),
        ];
        measure("opt_ood", &size, &mut cases, samples, rng);
        let lo = log.min(12);
        let mut tail = vec![Gf::zero(); 1 << lo];
        let mut head = vec![Gf::zero(); 1 << (log - lo)];
        let mut cases = vec![
            Case::new("allocate", p.len() * 16, || {
                black_box(ood(black_box(&p), black_box(&point)));
            }),
            Case::new("scratch", p.len() * 16, || {
                black_box(ood_reuse(
                    black_box(&p),
                    black_box(&point),
                    black_box(&mut tail),
                    black_box(&mut head),
                ));
            }),
        ];
        measure("opt_ood_reuse", &size, &mut cases, samples, rng);
    }
}

#[inline(always)]
fn butterfly(values: &mut [F128], t: F128) {
    let (a, b) = values.split_at_mut(values.len() / 2);
    if t == F128::ZERO {
        for (a, b) in a.iter_mut().zip(b) {
            *b += *a;
        }
    } else {
        let p = arithmetic::Prepared::new(t);
        for (a, b) in a.iter_mut().zip(b) {
            *a += p.mul(*b);
            *b += *a;
        }
    }
}

// Cache-local depth-first schedule, with public block/length decisions. It
// does not allocate a layer plan or enter a parallel iterator at every layer.
fn subtree(ntt: &AdditiveNttF128, data: &mut [F128], lanes: usize, layer: usize, block: usize) {
    if data.len() == lanes {
        return;
    }
    butterfly(data, ntt.twiddle(layer, block));
    let len = data.len();
    let (a, b) = data.split_at_mut(len / 2);
    if len >= 1 << 15 && rayon::current_num_threads() > 1 {
        rayon::join(
            || subtree(ntt, a, lanes, layer + 1, block * 2),
            || subtree(ntt, b, lanes, layer + 1, block * 2 + 1),
        );
    } else {
        subtree(ntt, a, lanes, layer + 1, block * 2);
        subtree(ntt, b, lanes, layer + 1, block * 2 + 1);
    }
}
fn ntt_cases(samples: usize, rng: &mut Rng) {
    for (log, lanes) in [
        (8, 1),
        (8, 32),
        (12, 8),
        (15, 8),
        (15, 32),
        (16, 32),
        (18, 32),
    ] {
        let size = format!("log{log}_lanes{lanes}");
        if !case_requested("opt_ntt", &size) {
            continue;
        }
        let basis: Vec<_> = (0..log)
            .map(|i| arithmetic::from_u128(1u128 << i))
            .collect();
        let ntt = AdditiveNttF128::new(&basis);
        let input = rng.values((1 << log) * lanes);
        let mut old = input.clone();
        let mut candidate = input.clone();
        ntt.forward_transform_interleaved(&mut old, lanes);
        subtree(&ntt, &mut candidate, lanes, 0, 0);
        assert_eq!(old, candidate);
        let mut cases = vec![
            Case::new("production", input.len() * 48, || {
                old.copy_from_slice(black_box(&input));
                ntt.forward_transform_interleaved(black_box(&mut old), lanes);
                black_box(&old);
            }),
            Case::new("depth_first", input.len() * 48, || {
                candidate.copy_from_slice(black_box(&input));
                subtree(black_box(&ntt), black_box(&mut candidate), lanes, 0, 0);
                black_box(&candidate);
            }),
        ];
        measure("opt_ntt", &size, &mut cases, samples, rng);
    }
}

// All 16 output lanes are initialized exactly once, including padding. The
// returned Vec survives OOD evaluation for the subsequent opening consumer.
fn pack(g: &crate::production_packing::Geometry, sources: [&[F128]; 2]) -> Vec<F128> {
    assert_eq!(g.lanes(), 16);
    let n = 1 << g.position_log;
    for b in 0..2 {
        assert_eq!(sources[b].len(), n << g.lane_logs[b]);
        assert!(g.lane_logs[b] <= 3);
    }
    let mut out = Vec::with_capacity(n * 16);
    for pos in 0..n {
        let mut group = [F128::ZERO; 16];
        for b in 0..2 {
            let k = g.lane_logs[b];
            let words = &sources[b][pos << k..(pos + 1) << k];
            group[b * 8..b * 8 + words.len()].copy_from_slice(words);
        }
        out.extend_from_slice(&group);
    }
    out
}
fn packing_cases(samples: usize, rng: &mut Rng) {
    for logs in [[9, 9], [16, 14], [18, 18]] {
        let size = format!("logs{}_{}", logs[0], logs[1]);
        if !["opt_pack", "opt_packed_ood"]
            .iter()
            .any(|f| case_requested(f, &size))
        {
            continue;
        }
        let position_log = logs[0].max(logs[1]) - 3;
        let g = crate::production_packing::Geometry {
            position_log,
            lane_logs: logs.map(|l| l.max(position_log) - position_log),
            virtual_lane_log: 4,
        };
        let a = rng.values(1 << (position_log + g.lane_logs[0]));
        let b = rng.values(1 << (position_log + g.lane_logs[1]));
        let sources = [a.as_slice(), b.as_slice()];
        let expected = g.virtual_packed(sources);
        assert_eq!(pack(&g, sources), expected);
        let point: Vec<_> = rng
            .values(g.packed_log())
            .iter()
            .map(|v| Gf::from_words([v.lo, v.hi]))
            .collect();
        assert_eq!(
            ood(&expected, &point),
            crate::production_ood::evaluate(&expected, &point)
        );
        let mut cases = vec![
            Case::new("production", expected.len() * 16, || {
                black_box(g.virtual_packed(black_box(sources)));
            }),
            Case::new("single_write", expected.len() * 16, || {
                black_box(pack(black_box(&g), black_box(sources)));
            }),
        ];
        measure("opt_pack", &size, &mut cases, samples, rng);
        let mut cases = vec![
            Case::new("production", expected.len() * 32, || {
                let packed = g.virtual_packed(black_box(sources));
                let y = crate::production_ood::evaluate(&packed, black_box(&point));
                black_box((packed, y));
            }),
            Case::new("single_write_ood", expected.len() * 32, || {
                let packed = pack(black_box(&g), black_box(sources));
                let y = ood(&packed, black_box(&point));
                black_box((packed, y));
            }),
        ];
        measure("opt_packed_ood", &size, &mut cases, samples, rng);
    }
}

pub(super) fn run(samples: usize, rng: &mut Rng) {
    ood_cases(samples, rng);
    ntt_cases(samples, rng);
    packing_cases(samples, rng);
}
