use super::pass;
use crate::{Case, Rng, arithmetic, case_requested, measure};
use f2z::{
    poly::univariate::{
        binary_b127::BinaryFieldB127 as B127, binary_gf128::BinaryFieldGF128 as Gf,
    },
    utils::wide_mul::WideMulAcc,
};
use flock_core::field::{F8, F128};
use std::hint::black_box;

#[inline(always)]
fn half(a: F128, b: u64) -> F128 {
    #[cfg(all(target_arch = "aarch64", target_feature = "aes"))]
    unsafe {
        use core::arch::aarch64::*;
        let lo = vreinterpretq_u64_p128(vmull_p64(a.lo, b));
        let hi = vreinterpretq_u64_p128(vmull_p64(a.hi, b));
        let fold = vreinterpretq_u64_p128(vmull_p64(vgetq_lane_u64::<1>(hi), 0x87));
        let out = veorq_u64(veorq_u64(lo, vextq_u64::<1>(vdupq_n_u64(0), hi)), fold);
        F128::new(vgetq_lane_u64::<0>(out), vgetq_lane_u64::<1>(out))
    }
    #[cfg(not(all(target_arch = "aarch64", target_feature = "aes")))]
    {
        arithmetic::half_mul(a, b)
    }
}

#[inline(never)]
pub(super) fn fixed(input: &[F128], t: F128, output: &mut [F128]) {
    assert_eq!(input.len(), output.len());
    // t is a public pass-constant; shape dispatch happens once per pass.
    if t == F128::ZERO {
        output.fill(F128::ZERO);
    } else if t.hi == 0 {
        for (&a, o) in input.iter().zip(output) {
            *o = half(a, t.lo);
        }
    } else {
        let p = arithmetic::Prepared::new(t);
        for (&a, o) in input.iter().zip(output) {
            *o = p.mul(a);
        }
    }
}

fn fixed_cases(samples: usize, rng: &mut Rng) {
    use crate::production_fixed::{BinaryFieldGF128 as Wrapped, FixedGfMul};
    for (label, t) in [
        ("zero", F128::ZERO),
        ("half", F128::new(0xabcdef0123456789, 0)),
        ("full", F128::new(0x123456789abcdef, 0xfedcba9876543210)),
    ] {
        let prep = arithmetic::Prepared::new(t);
        let native = FixedGfMul::new(Wrapped::from_words([t.lo, t.hi]));
        for n in [0, 1, 3, 17, 16, 1024, 65536] {
            let size = format!("{label}_n{n}");
            if (n == 16 || n == 1024 || n == 65536)
                && !["opt_gf_fixed", "opt_gf_butterfly"]
                    .iter()
                    .any(|f| case_requested(f, &size))
            {
                continue;
            }
            let a = rng.values(n);
            let b = rng.values(n);
            let expected: Vec<_> = a.iter().map(|&a| a * t).collect();
            let mut o = vec![F128::ZERO; n];
            fixed(&a, t, &mut o);
            assert_eq!(o, expected);
            for (&a, &o) in a.iter().zip(&o).take(256) {
                assert_eq!(o, arithmetic::oracle(a, t));
                assert_eq!(
                    *native.mul(Wrapped::from_words([a.lo, a.hi])).words(),
                    [o.lo, o.hi]
                );
            }
            if n < 16 || n == 17 {
                continue;
            }
            let mut cases = vec![
                pass("actual_fixed_gf", n * 32, &a, &expected, |a, o| {
                    for (&x, o) in a.iter().zip(o) {
                        let w = *native.mul(Wrapped::from_words([x.lo, x.hi])).words();
                        *o = F128::new(w[0], w[1]);
                    }
                }),
                pass("prepared_formula", n * 32, &a, &expected, |a, o| {
                    for (&x, o) in a.iter().zip(o) {
                        *o = prep.mul(x);
                    }
                }),
                pass("public_scalar_dispatch", n * 32, &a, &expected, |a, o| {
                    fixed(a, t, o)
                }),
            ];
            measure("opt_gf_fixed", &size, &mut cases, samples, rng);
            let pairs: Vec<_> = a.iter().zip(b).map(|(&a, b)| (a, b)).collect();
            let expected: Vec<_> = pairs
                .iter()
                .map(|&(a, b)| {
                    let x = a + b * t;
                    (x, x + b)
                })
                .collect();
            let mut cases = vec![
                pass("actual_fixed_gf", n * 64, &pairs, &expected, |a, o| {
                    for (&(a, b), o) in a.iter().zip(o) {
                        let w = *native.mul(Wrapped::from_words([b.lo, b.hi])).words();
                        let x = a + F128::new(w[0], w[1]);
                        *o = (x, x + b);
                    }
                }),
                pass(
                    "public_scalar_dispatch",
                    n * 64,
                    &pairs,
                    &expected,
                    |a, o| {
                        if t == F128::ZERO {
                            for (&(a, b), o) in a.iter().zip(o) {
                                *o = (a, a + b);
                            }
                        } else if t.hi == 0 {
                            for (&(a, b), o) in a.iter().zip(o) {
                                let x = a + half(b, t.lo);
                                *o = (x, x + b);
                            }
                        } else {
                            for (&(a, b), o) in a.iter().zip(o) {
                                let x = a + prep.mul(b);
                                *o = (x, x + b);
                            }
                        }
                    },
                ),
            ];
            measure("opt_gf_butterfly", &size, &mut cases, samples, rng);
        }
    }
}

fn round<const K: usize>(l: &[Gf], r: &[Gf], w: &[Gf]) -> (Gf, Gf, Gf) {
    assert_eq!(l.len(), 2 * w.len());
    assert_eq!(r.len(), l.len());
    let zero = Gf::wide_zero(&Gf::zero());
    let mut acc = [[zero; 3]; K];
    for (i, ((&w, l), r)) in w
        .iter()
        .zip(l.chunks_exact(2))
        .zip(r.chunks_exact(2))
        .enumerate()
    {
        let a = l[0] * w;
        let b = l[1] * w;
        let slot = &mut acc[i % K];
        Gf::wide_add_assign(&mut slot[0], &Gf::mul_wide(&a, &r[0]));
        Gf::wide_add_assign(&mut slot[1], &Gf::mul_wide(&b, &r[1]));
        Gf::wide_add_assign(&mut slot[2], &Gf::mul_wide(&(a + b), &(r[0] + r[1])));
    }
    let mut merged = [zero; 3];
    for a in acc {
        for (i, a) in a.iter().enumerate() {
            Gf::wide_add_assign(&mut merged[i], a);
        }
    }
    let [c0, c1, c2] = merged.map(Gf::from_wide);
    (c0, c1 + c0 + c2, c2)
}
fn rounds(samples: usize, rng: &mut Rng) {
    for n in [0, 1, 3, 17, 16, 1024, 65536] {
        let size = n.to_string();
        if (n == 16 || n == 1024 || n == 65536) && !case_requested("opt_gf_round", &size) {
            continue;
        }
        let mut vals = |n| {
            rng.values(n)
                .iter()
                .map(|x| Gf::from_words([x.lo, x.hi]))
                .collect::<Vec<_>>()
        };
        let l = vals(2 * n);
        let r = vals(2 * n);
        let w = vals(n);
        let expected = Gf::eqf_single_pair_round(&l, &r, &w, n).unwrap();
        assert_eq!(round::<1>(&l, &r, &w), expected);
        assert_eq!(round::<2>(&l, &r, &w), expected);
        if n < 16 || n == 17 {
            continue;
        }
        let mut cases = vec![
            Case::new("production_fused", n * 80, || {
                black_box(
                    Gf::eqf_single_pair_round(black_box(&l), black_box(&r), black_box(&w), n)
                        .unwrap(),
                );
            }),
            Case::new("wide1", n * 80, || {
                black_box(round::<1>(black_box(&l), black_box(&r), black_box(&w)));
            }),
            Case::new("wide2", n * 80, || {
                black_box(round::<2>(black_box(&l), black_box(&r), black_box(&w)));
            }),
        ];
        measure("opt_gf_round", &size, &mut cases, samples, rng);
    }
}

fn add_coefficients(a: (Gf, Gf, Gf), b: (Gf, Gf, Gf)) -> (Gf, Gf, Gf) {
    (a.0 + b.0, a.1 + b.1, a.2 + b.2)
}
fn hook_cases(samples: usize, rng: &mut Rng) {
    for n in [16, 1024] {
        let size = n.to_string();
        if !["opt_gf_two_pair", "opt_gf_fold_round", "opt_gf_grid"]
            .iter()
            .any(|f| case_requested(f, &size))
        {
            continue;
        }
        let mut values = |n| {
            rng.values(n)
                .iter()
                .map(|v| Gf::from_words([v.lo, v.hi]))
                .collect::<Vec<_>>()
        };
        let l = values(16 * n);
        let r = values(16 * n);
        let w = values(n);
        let challenges = values(2);
        let rho = challenges[0];
        let reference = Gf::eqf_two_pair_round(
            &l[..2 * n],
            &r[..2 * n],
            &l[2 * n..4 * n],
            &r[2 * n..4 * n],
            &w,
            n,
        )
        .unwrap();
        let separate = || {
            add_coefficients(
                round::<1>(&l[..2 * n], &r[..2 * n], &w),
                round::<1>(&l[2 * n..4 * n], &r[2 * n..4 * n], &w),
            )
        };
        assert_eq!(separate(), reference);
        let mut cases = vec![
            Case::new("production_fused", n * 144, || {
                black_box(
                    Gf::eqf_two_pair_round(
                        black_box(&l[..2 * n]),
                        black_box(&r[..2 * n]),
                        black_box(&l[2 * n..4 * n]),
                        black_box(&r[2 * n..4 * n]),
                        black_box(&w),
                        n,
                    )
                    .unwrap(),
                );
            }),
            Case::new("separate_wide", n * 144, || {
                black_box(add_coefficients(
                    round::<1>(
                        black_box(&l[..2 * n]),
                        black_box(&r[..2 * n]),
                        black_box(&w),
                    ),
                    round::<1>(
                        black_box(&l[2 * n..4 * n]),
                        black_box(&r[2 * n..4 * n]),
                        black_box(&w),
                    ),
                ));
            }),
        ];
        measure("opt_gf_two_pair", &size, &mut cases, samples, rng);
        let mut l0 = l[..4 * n].to_vec();
        let mut r0 = r[..4 * n].to_vec();
        let mut l1 = l0.clone();
        let mut r1 = r0.clone();
        let expected = Gf::eqf_fused_fold_round(&mut l0, &mut r0, &rho, &w, n).unwrap();
        assert!(Gf::eqf_fold_in_place(&mut l1, &rho, 2 * n));
        assert!(Gf::eqf_fold_in_place(&mut r1, &rho, 2 * n));
        assert_eq!(round::<1>(&l1[..2 * n], &r1[..2 * n], &w), expected);
        assert_eq!(&l0[..2 * n], &l1[..2 * n]);
        assert_eq!(&r0[..2 * n], &r1[..2 * n]);
        let mut cases = vec![
            Case::new("production_fused", n * 256, || {
                l0.copy_from_slice(black_box(&l[..4 * n]));
                r0.copy_from_slice(black_box(&r[..4 * n]));
                black_box(
                    Gf::eqf_fused_fold_round(
                        black_box(&mut l0),
                        black_box(&mut r0),
                        black_box(&rho),
                        black_box(&w),
                        n,
                    )
                    .unwrap(),
                );
                black_box((&l0, &r0));
            }),
            Case::new("fold_then_wide", n * 256, || {
                l1.copy_from_slice(black_box(&l[..4 * n]));
                r1.copy_from_slice(black_box(&r[..4 * n]));
                assert!(Gf::eqf_fold_in_place(
                    black_box(&mut l1),
                    black_box(&rho),
                    2 * n
                ));
                assert!(Gf::eqf_fold_in_place(
                    black_box(&mut r1),
                    black_box(&rho),
                    2 * n
                ));
                black_box(round::<1>(
                    black_box(&l1[..2 * n]),
                    black_box(&r1[..2 * n]),
                    black_box(&w),
                ));
                black_box((&l1, &r1));
            }),
        ];
        measure("opt_gf_fold_round", &size, &mut cases, samples, rng);
        let mut l0 = l.clone();
        let mut r0 = r.clone();
        let mut l1 = l.clone();
        let mut r1 = r.clone();
        let expected = Gf::eqf_grid_pass(&mut l0, &mut r0, &challenges, &w, n).unwrap();
        fn chunks(l: &mut [Gf], r: &mut [Gf], p: &[Gf], w: &[Gf]) -> [Gf; 9] {
            let mut out = [Gf::zero(); 9];
            for start in (0..w.len()).step_by(128) {
                let end = (start + 128).min(w.len());
                let offset = start * 16;
                let c = Gf::eqf_grid_pass(
                    &mut l[offset..end * 16],
                    &mut r[offset..end * 16],
                    p,
                    &w[start..end],
                    end - start,
                )
                .unwrap();
                l.copy_within(offset..offset + (end - start) * 4, start * 4);
                r.copy_within(offset..offset + (end - start) * 4, start * 4);
                for (i, c) in c.into_iter().enumerate() {
                    out[i] += c;
                }
            }
            out
        }
        assert_eq!(chunks(&mut l1, &mut r1, &challenges, &w), expected);
        assert_eq!(&l0[..4 * n], &l1[..4 * n]);
        assert_eq!(&r0[..4 * n], &r1[..4 * n]);
        let mut cases = vec![
            Case::new("production_fused", n * 1024, || {
                l0.copy_from_slice(black_box(&l));
                r0.copy_from_slice(black_box(&r));
                black_box(
                    Gf::eqf_grid_pass(
                        black_box(&mut l0),
                        black_box(&mut r0),
                        black_box(&challenges),
                        black_box(&w),
                        n,
                    )
                    .unwrap(),
                );
                black_box((&l0[..4 * n], &r0[..4 * n]));
            }),
            Case::new("chunked", n * 1024, || {
                l1.copy_from_slice(black_box(&l));
                r1.copy_from_slice(black_box(&r));
                black_box(chunks(
                    black_box(&mut l1),
                    black_box(&mut r1),
                    black_box(&challenges),
                    black_box(&w),
                ));
                black_box((&l1[..4 * n], &r1[..4 * n]));
            }),
        ];
        measure("opt_gf_grid", &size, &mut cases, samples, rng);
    }
}

#[inline(always)]
fn byte_mul(a: u8, b: u8) -> u8 {
    let mut a = a;
    let mut out = 0;
    for i in 0..8 {
        out ^= a & 0u8.wrapping_sub((b >> i) & 1);
        a = (a << 1) ^ (0x1b & 0u8.wrapping_sub(a >> 7));
    }
    out
}
#[inline(never)]
fn bytes(a: &[u8], b: &[u8], out: &mut [u8]) {
    assert_eq!(a.len(), b.len());
    assert_eq!(a.len(), out.len());
    let n = a.len() / 16 * 16;
    #[cfg(target_arch = "aarch64")]
    for ((a, b), o) in a[..n]
        .chunks_exact(16)
        .zip(b[..n].chunks_exact(16))
        .zip(out[..n].chunks_exact_mut(16))
    {
        unsafe {
            use core::arch::aarch64::*;
            let v = flock_core::field::gf2_8::neon::gf8_mul_vec16(
                vld1q_u8(a.as_ptr()),
                vld1q_u8(b.as_ptr()),
            );
            vst1q_u8(o.as_mut_ptr(), v);
        }
    }
    #[cfg(not(target_arch = "aarch64"))]
    for ((&a, &b), o) in a[..n].iter().zip(&b[..n]).zip(&mut out[..n]) {
        *o = byte_mul(a, b);
    }
    for ((&a, &b), o) in a[n..].iter().zip(&b[n..]).zip(&mut out[n..]) {
        *o = byte_mul(a, b);
    }
}
#[inline(always)]
fn byte_inverse(x: u8) -> u8 {
    let x2 = byte_mul(x, x);
    let x3 = byte_mul(x2, x);
    let x6 = byte_mul(x3, x3);
    let x12 = byte_mul(x6, x6);
    let x15 = byte_mul(x12, x3);
    let x30 = byte_mul(x15, x15);
    let x60 = byte_mul(x30, x30);
    let x120 = byte_mul(x60, x60);
    let x240 = byte_mul(x120, x120);
    byte_mul(byte_mul(x240, x12), x2)
}
fn byte_inverses(input: &[u8], out: &mut [u8]) {
    assert_eq!(input.len(), out.len());
    let n = input.len() / 16 * 16;
    #[cfg(target_arch = "aarch64")]
    for (a, o) in input[..n]
        .chunks_exact(16)
        .zip(out[..n].chunks_exact_mut(16))
    {
        unsafe {
            use core::arch::aarch64::*;
            use flock_core::field::gf2_8::neon::gf8_mul_vec16 as mul;
            let x = vld1q_u8(a.as_ptr());
            let x2 = mul(x, x);
            let x3 = mul(x2, x);
            let x6 = mul(x3, x3);
            let x12 = mul(x6, x6);
            let x15 = mul(x12, x3);
            let x30 = mul(x15, x15);
            let x60 = mul(x30, x30);
            let x120 = mul(x60, x60);
            let x240 = mul(x120, x120);
            let x252 = mul(x240, x12);
            vst1q_u8(o.as_mut_ptr(), mul(x252, x2));
        }
    }
    #[cfg(not(target_arch = "aarch64"))]
    for (&a, o) in input[..n].iter().zip(&mut out[..n]) {
        *o = byte_inverse(a);
    }
    for (&a, o) in input[n..].iter().zip(&mut out[n..]) {
        *o = byte_inverse(a);
    }
}
fn small_fields(samples: usize, rng: &mut Rng) {
    let domain: Vec<_> = (0..=255).collect();
    let mut inverse = vec![0; 256];
    byte_inverses(&domain, &mut inverse);
    for (&a, &b) in domain.iter().zip(&inverse) {
        assert_eq!(b, F8(a).inv().0);
        assert_eq!(byte_inverse(a), b);
    }
    for a in 0..=255 {
        for b in 0..=255 {
            assert_eq!(byte_mul(a, b), (F8(a) * F8(b)).0);
        }
    }
    let basis: Vec<_> = (0..8)
        .map(|i| flock_core::field::phi8::phi8(F8(1 << i)))
        .collect();
    let embedding = |a: u8| {
        let mut out = F128::ZERO;
        for (i, &b) in basis.iter().enumerate() {
            let mask = 0u64.wrapping_sub(((a >> i) & 1) as u64);
            out += F128::new(b.lo & mask, b.hi & mask);
        }
        out
    };
    for a in 0..=255 {
        assert_eq!(embedding(a), flock_core::field::phi8::phi8(F8(a)));
    }
    for n in [0, 1, 15, 17, 16, 1024, 65536] {
        let size = n.to_string();
        if [16, 1024, 65536].contains(&n)
            && !["opt_gf8_mul", "opt_gf8_inverse", "opt_phi8", "opt_b127_mul"]
                .iter()
                .any(|f| case_requested(f, &size))
        {
            continue;
        }
        let a: Vec<_> = (0..n).map(|_| rng.next() as u8).collect();
        let b: Vec<_> = (0..n).map(|_| rng.next() as u8).collect();
        let expected: Vec<_> = a.iter().zip(&b).map(|(&a, &b)| (F8(a) * F8(b)).0).collect();
        let mut out = vec![0; n];
        bytes(&a, &b, &mut out);
        assert_eq!(out, expected);
        if ![16, 1024, 65536].contains(&n) {
            continue;
        }
        let mut cases = vec![
            pass("flock_scalar", n * 3, &a, &expected, |a, o| {
                for ((&a, &b), o) in a.iter().zip(&b).zip(o) {
                    *o = (F8(a) * F8(b)).0;
                }
            }),
            pass("native_batch", n * 3, &a, &expected, |a, o| bytes(a, &b, o)),
        ];
        measure("opt_gf8_mul", &size, &mut cases, samples, rng);
        let expected: Vec<_> = a.iter().map(|&a| F8(a).inv().0).collect();
        let mut cases = vec![
            pass("flock_scalar", n * 2, &a, &expected, |a, o| {
                for (&a, o) in a.iter().zip(o) {
                    *o = F8(a).inv().0;
                }
            }),
            pass("vector_chain", n * 2, &a, &expected, |a, o| {
                byte_inverses(a, o)
            }),
        ];
        measure("opt_gf8_inverse", &size, &mut cases, samples, rng);
        let expected: Vec<_> = a.iter().map(|&a| embedding(a)).collect();
        let mut cases = vec![
            pass("table_public_input", n * 17, &a, &expected, |a, o| {
                for (&a, o) in a.iter().zip(o) {
                    *o = flock_core::field::phi8::phi8(F8(a));
                }
            }),
            pass("fixed_basis", n * 17, &a, &expected, |a, o| {
                for (&a, o) in a.iter().zip(o) {
                    *o = embedding(a);
                }
            }),
        ];
        measure("opt_phi8", &size, &mut cases, samples, rng);
        let a: Vec<_> = rng
            .values(n)
            .iter()
            .map(|v| B127::from_words([v.lo, v.hi >> 1]))
            .collect();
        let b: Vec<_> = rng
            .values(n)
            .iter()
            .map(|v| B127::from_words([v.lo, v.hi >> 1]))
            .collect();
        let expected: Vec<_> = a.iter().zip(&b).map(|(&a, &b)| a * b).collect();
        let mut cases = vec![pass("production", n * 48, &a, &expected, |a, o| {
            for ((&a, &b), o) in a.iter().zip(&b).zip(o) {
                *o = a * b;
            }
        })];
        #[cfg(target_arch = "aarch64")]
        {
            cases.push(pass("karatsuba", n * 48, &a, &expected, |a, o| {
                for ((a, b), o) in a.iter().zip(&b).zip(o) {
                    *o = a.mul_karatsuba(b);
                }
            }));
            cases.push(pass("pfold", n * 48, &a, &expected, |a, o| {
                for ((a, b), o) in a.iter().zip(&b).zip(o) {
                    *o = a.mul_pfold(b);
                }
            }));
        }
        measure("opt_b127_mul", &size, &mut cases, samples, rng);
    }
}

fn polynomial<const A: usize, const B: usize, const O: usize>(samples: usize, rng: &mut Rng) {
    use f2z::poly::univariate::binary_f2_wide::{BinaryF2Poly as Poly, f2_inner_product};
    fn fixed<const A: usize, const B: usize, const O: usize>(
        a: &[Poly<A>],
        b: &[Poly<B>],
    ) -> Poly<O> {
        assert!(O >= A + B);
        assert_eq!(a.len(), b.len());
        let mut out = [0; O];
        for (a, b) in a.iter().zip(b) {
            for i in 0..A {
                for j in 0..B {
                    let p = arithmetic::clmul(a.words()[i], b.words()[j]);
                    out[i + j] ^= p as u64;
                    out[i + j + 1] ^= (p >> 64) as u64;
                }
            }
        }
        Poly::from_words(out)
    }
    for class in ["dense", "sparse"] {
        for n in [0, 1, 3, 17, 16, 1024] {
            let size = format!("a{A}_b{B}_{class}_n{n}");
            if [16, 1024].contains(&n) && !case_requested("opt_f2_poly_dot", &size) {
                continue;
            }
            let mut word = || {
                let x = rng.next();
                if class == "sparse" && x & 3 != 0 {
                    0
                } else {
                    x
                }
            };
            let a: Vec<_> = (0..n)
                .map(|_| Poly::<A>::from_words(std::array::from_fn(|_| word())))
                .collect();
            let b: Vec<_> = (0..n)
                .map(|_| Poly::<B>::from_words(std::array::from_fn(|_| word())))
                .collect();
            let expected = f2_inner_product::<A, B, O>(&a, &b);
            assert_eq!(fixed::<A, B, O>(&a, &b), expected);
            if ![16, 1024].contains(&n) {
                continue;
            }
            let mut cases = vec![
                Case::new("production_zero_skip", n * (A + B) * 8, || {
                    black_box(f2_inner_product::<A, B, O>(black_box(&a), black_box(&b)));
                }),
                Case::new("fixed_schedule", n * (A + B) * 8, || {
                    black_box(fixed::<A, B, O>(black_box(&a), black_box(&b)));
                }),
            ];
            measure("opt_f2_poly_dot", &size, &mut cases, samples, rng);
        }
    }
}

pub(super) fn run(samples: usize, rng: &mut Rng) {
    fixed_cases(samples, rng);
    rounds(samples, rng);
    hook_cases(samples, rng);
    small_fields(samples, rng);
    polynomial::<1, 1, 2>(samples, rng);
    polynomial::<3, 7, 10>(samples, rng);
    polynomial::<9, 9, 18>(samples, rng);
}
