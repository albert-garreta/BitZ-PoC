#!/usr/bin/env python3
"""Freeze sources and selections, build once, then measure fresh paired processes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tempfile
import time

from analysis import DEFAULT_MARGIN, SPEC_PATH, expanded, summarize_round, write_report

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + "\n")


def candidate_snapshot(work):
    """Change scalar multiplication only in a private copy of Flock.

    Keeping all NTT sources byte-identical retains fused and cache-blocked
    kernels, including specialized multiplication they already use internally.
    """
    experiment = work / "experiments/field-regressions"
    baseline = work / "vendor/flock-mod"
    candidate = work / "vendor/flock-candidate"
    shutil.copytree(baseline, candidate)
    manifest = candidate / "Cargo.toml"
    manifest.write_text(manifest.read_text().replace(
        'members = ["crates/flock-core", "crates/flock-prover"]',
        'members = ["crates/flock-core"]'))
    core = candidate / "crates/flock-core"
    manifest = core / "Cargo.toml"
    manifest.write_text(manifest.read_text().replace('name = "flock-core"', 'name = "flock-core-candidate"\nworkspace = "../.."', 1).replace(
        '[dependencies]', '[dependencies]\nfield = { path = ' + json.dumps(str(work / 'crates/field')) + ' }', 1))
    source = core / "src/field/gf2_128.rs"
    content = source.read_text()
    begin = content.index("impl Mul for F128 {")
    end = content.index("\nimpl MulAssign", begin)
    content = content[:begin] + '''impl Mul for F128 {
    type Output = Self;
    #[inline]
    fn mul(self, rhs: Self) -> Self {
        let value = crate::experiment_scalar_kernel::mul(
            field::F128::new(self.lo, self.hi), field::F128::new(rhs.lo, rhs.hi));
        Self::new(value.lo, value.hi)
    }
}
''' + content[end:]
    source.write_text(content)
    shutil.copy2(experiment / "src/scalar_kernel.rs", core / "src/experiment_scalar_kernel.rs")
    library = core / "src/lib.rs"
    library.write_text(library.read_text() + "\nmod experiment_scalar_kernel;\n")
    unchanged = {}
    for path in (baseline / "crates/flock-core/src").rglob("*.rs"):
        relative = path.relative_to(baseline / "crates/flock-core")
        if "ntt" in relative.parts or path.name == "ntt.rs":
            assert sha(path) == sha(core / relative), relative
            unchanged[str(relative)] = sha(path)
    assert unchanged, "NTT sources not found"
    manifest = experiment / "Cargo.toml"
    manifest.write_text(manifest.read_text().replace('[dependencies]', '''[dependencies]
flock-candidate = { package = "flock-core-candidate", path = "../../vendor/flock-candidate/crates/flock-core", optional = true }''', 1).replace(
        'ntt-candidate = []', 'ntt-candidate = ["dep:flock-candidate"]'))
    generated = {str(p.relative_to(work)): sha(p) for p in candidate.rglob("*") if p.is_file()}
    generated[str(manifest.relative_to(work))] = sha(manifest)
    return unchanged, generated


def clean_environment(flags, target, threads):
    env = os.environ.copy()
    for key in list(env):
        if key.startswith("CARGO_PROFILE_") or key in {
                "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER",
                "NTT_DEEP_NOFUSE", "NTT_DEEP_PCORES_ONLY", "FIELD_REGRESSION_CASES", "F2Z_FIXED_SCALAR", "FIELD_REGRESSION_BASELINES"}:
            env.pop(key)
    env.update(RUSTFLAGS=flags, CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS="2", RAYON_NUM_THREADS=str(threads))
    return env


def run_round(out, metadata, spec, binary, env, cases=None):
    out.mkdir()
    save(out / "metadata.json", metadata)
    run_env = env.copy()
    run_env["FIELD_REGRESSION_BASELINES"]=json.dumps({g["name"]:g["baseline"] for g in spec["families"]})
    if cases:
        run_env["FIELD_REGRESSION_CASES"] = ",".join(sorted(cases))
    for run in range(metadata["runs"]):
        assert sha(binary) == metadata["binary_sha256"], "Frozen binary changed"
        print(f'{out.name}: process {run+1}/{metadata["runs"]}, {metadata["samples"]} paired samples', flush=True)
        with (out / f"run-{run}.csv").open("w") as data, (out / f"run-{run}.log").open("w") as log:
            subprocess.run([str(binary), metadata.get("mode","gf"), str(metadata["samples"]), str(metadata["seed_offset"] + 7919*run)],
                           env=run_env, stdout=data, stderr=log, check=True)
    print(f"Analyzing {out.name} confidence intervals", flush=True)
    rows, runtimes = summarize_round(out, metadata, spec)
    metadata = dict(metadata, runtimes=runtimes, status="complete",
                    artifacts_sha256={p.name:sha(p) for p in sorted(out.glob("run-*.*"))})
    save(out / "metadata.json", metadata)
    write_report(out, rows, metadata["margin"], metadata.get("report_title","GF128 and NTT regression measurements"))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--suite", choices=["gf-ntt","arithmetic"], default="gf-ntt")
    parser.add_argument("--arch", choices=["aarch64","x86_64"], help="Host campaign scope; other architecture is a separate run")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--runs", type=int, default=5)
    parser.add_argument("--samples", type=int, default=32)
    parser.add_argument("--margin", type=float, default=DEFAULT_MARGIN)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--flags", default="-C target-cpu=native")
    parser.add_argument("--target-dir", type=Path, help="Optional experiment-owned build cache")
    parser.add_argument("--cases", help="Comma-separated family/size IDs; omitted cases remain unmeasured")
    parser.add_argument("--no-retry", action="store_true", help="Development run: disable the one inconclusive-case retry")
    args = parser.parse_args()
    spec_path = HERE / "arithmetic_cases.json" if args.suite=="arithmetic" else SPEC_PATH
    spec = json.loads(spec_path.read_text())
    arch = {"arm64": "aarch64", "AMD64": "x86_64"}.get(platform.machine(), platform.machine())
    if args.arch and arch!=args.arch:
        parser.error("Requested architecture does not match this host")
    if arch not in spec["architectures"]:
        parser.error(f"{arch} is outside this campaign's explicit architecture scope")
    if args.suite=="arithmetic":
        spec["architectures"]=[arch]
    if min(args.runs, args.samples, args.threads) < 1 or not 0 <= args.margin < 1:
        parser.error("positive run/sample/thread counts and a margin in [0, 1) are required")
    cases = set(args.cases.split(",")) if args.cases else None
    valid_cases = {r["family"]+"/"+r["size"] for r in expanded(spec)}
    if cases and not cases <= valid_cases:
        parser.error(f"Unknown cases: {cases-valid_cases}")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    work = Path(tempfile.mkdtemp(prefix="f2z-field-gated-"))
    print(f"Frozen snapshot: {work}", flush=True)
    hashes = {}
    for relative in ["src", "benches", "tests", "examples", "crates/field", "crates/circuit", "vendor/crypto-primitives", "vendor/flock-mod", "experiments/field-regressions"]:
        dest = work / relative
        shutil.copytree(ROOT / relative, dest, ignore=shutil.ignore_patterns(
            "target", ".git", "results", "__pycache__", "candidate-flock"))
        hashes.update({str(p.relative_to(work)): sha(p) for p in dest.rglob("*") if p.is_file()})
    for relative in ["Cargo.toml", "Cargo.lock"]:
        shutil.copy2(ROOT / relative, work / relative)
        hashes[relative]=sha(work/relative)
    if args.suite=="arithmetic":
        ntt_hashes,generated_hashes={},{}
    else:
        ntt_hashes,generated_hashes=candidate_snapshot(work)
    save(out/"required_cases.json",spec)
    target = args.target_dir.resolve() if args.target_dir else work / "target"
    env = clean_environment(args.flags, target, args.threads)
    hardware = subprocess.run(["sysctl", "machdep.cpu.brand_string", "hw.memsize", "hw.physicalcpu", "hw.logicalcpu"]
                              if platform.system()=="Darwin" else ["lscpu"], capture_output=True, text=True)
    metadata = dict(hardware=hardware.stdout, schema=2, mode="arithmetic" if args.suite=="arithmetic" else "gf",
                    report_title="Unified arithmetic benchmark measurements" if args.suite=="arithmetic" else "GF128 and NTT regression measurements", timestamp=time.strftime("%Y-%m-%dT%H:%M:%S%z"), arch=arch,
                    platform=platform.platform(), rustc=subprocess.check_output(["rustc", "-Vv"], text=True),
                    flags=args.flags, threads=args.threads, runs=args.runs, samples=args.samples,
                    margin=args.margin, seed_offset=42, source_sha256=hashes, generated_sha256=generated_hashes,
                    unchanged_ntt_sha256=ntt_hashes, manifest_sha256=sha(out/"required_cases.json"), snapshot=str(work),
                    cases=sorted(cases) if cases else None, retry_enabled=not args.no_retry, status="building",
                    note="Host-specific campaign. Core placement, thermal state and unrelated system load are uncontrolled. No production integration.")
    save(out / "metadata.json", metadata)
    manifest = work / "experiments/field-regressions/Cargo.toml"
    build_start=time.monotonic()
    with (out / "build.log").open("w") as log:
        subprocess.run(["cargo", "build", "--offline", "--release", "--features", "arithmetic-campaign" if args.suite=="arithmetic" else "ntt-candidate", "--manifest-path", str(manifest)],
                       env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    shutil.copy2(manifest.with_name("Cargo.lock"), out / "Cargo.lock")
    binary = work / "field-regressions"
    shutil.copy2(target / "release/field-regressions", binary)
    metadata.update(build_seconds=time.monotonic()-build_start, binary_sha256=sha(binary), binary=str(binary), status="confirming")
    save(out / "metadata.json", metadata)
    rows = run_round(out / "initial", metadata, spec, binary, env, cases or (valid_cases if args.suite=="arithmetic" else None))
    retry = {r["family"]+"/"+r["size"] for r in rows if r["arch"]==arch and r["selected"] and r["status"]=="inconclusive"}
    if retry and not args.no_retry:
        retry_meta = dict(metadata, samples=args.samples*spec["retry_multiplier"], seed_offset=104729, cases=sorted(retry))
        retried = run_round(out / "retry", retry_meta, spec, binary, env, retry)
        replacements = {(r["arch"], r["family"], r["size"], r["variant"]): r for r in retried
                        if r["arch"]==arch and r["family"]+"/"+r["size"] in retry}
        rows = [replacements.get((r["arch"], r["family"], r["size"], r["variant"]), r) for r in rows]
    else:
        retry = set()
    write_report(out, rows, args.margin, metadata["report_title"])
    metadata.update(status="complete", retried_cases=sorted(retry),
                    round_metadata_sha256={name:sha(out/name/"metadata.json") for name in ["initial","retry"] if (out/name).exists()},
                    summary_sha256=sha(out/"summary.json"))
    save(out / "metadata.json", metadata)
    print(f"Report: {out / 'measurements.md'}", flush=True)


if __name__ == "__main__":
    main()
